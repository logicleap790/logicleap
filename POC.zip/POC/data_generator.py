"""
Data Generator Module for Logic Leap
Generates realistic manufacturing data with scenarios from POC_Production.txt
"""

import random
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path
import numpy as np

class DataGenerator:
    def __init__(self, storage_path: str = "storage"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(exist_ok=True)
        
        # Machine and tool configurations
        self.machines = [f"Machine_{i}" for i in range(1, 11)]
        self.molds = ["MOLD_AN_01", "MOLD_AN_02", "MOLD_AN_03", "MOLD_BX_01", "MOLD_BX_02"]
        self.operators = ["OP101", "OP102", "OP103", "OP115", "OP116", "OP117"]
        self.products = ["PART_A", "PART_B", "PART_C", "PART_D", "PART_E"]
        
        # Operator skill levels (from POC_Production.txt)
        self.operator_skill = {
            'OP115': 0.045,  # New operator, higher defects
            'OP116': 0.058,  # New operator, highest defects
            'OP101': 0.015,  # Expert, low defects
            'OP102': 0.018,
            'OP103': 0.020,
            'OP117': 0.035
        }
    
    def add_scenario_patterns(self, data: Dict, current_date: datetime) -> Dict:
        """Add realistic manufacturing scenarios from POC_Production.txt"""
        
        # 1. Tool Wear Pattern
        if current_date >= datetime(2024, 8, 1):
            days_since = (current_date - datetime(2024, 8, 1)).days
            if data.get('mold_id') == 'MOLD_AN_02':
                wear_factor = 0.02 + (0.08 * min(days_since / 14, 1))
                data['defect_rate'] = data.get('defect_rate', 0.01) + wear_factor
        
        # 2. Monsoon Material Moisture (Aug 15-25)
        if datetime(2024, 8, 15) <= current_date <= datetime(2024, 8, 25):
            if random.random() < 0.6:
                data['moisture_defect_multiplier'] = 3.0
                data['defect_rate'] = data.get('defect_rate', 0.01) * 3.0
        
        # 3. Power Quality Issues (2-5 PM in summer)
        if current_date.month in [4, 5, 6] and 14 <= current_date.hour <= 17:
            data['power_quality_factor'] = 1.5
            data['performance_factor'] = data.get('performance_factor', 1.0) * 0.85
        
        # 4. Maintenance Skip Consequences
        if data.get('machine_id') == 'Machine_8' and current_date >= datetime(2024, 8, 15):
            if current_date.date() == datetime(2024, 8, 18).date():
                data['catastrophic_failure'] = True
                data['downtime_minutes'] = 1080  # 18 hours
            elif datetime(2024, 8, 15) <= current_date < datetime(2024, 8, 18):
                data['performance_factor'] = 0.7
        
        return data
    
    def get_production_data(self, date: str = None, plant: str = None, 
                           line: str = None, machine: str = None, 
                           shift: str = None) -> List[Dict]:
        """Generate production data with realistic patterns"""
        
        if date:
            target_date = datetime.strptime(date, "%Y-%m-%d")
        else:
            target_date = datetime.now()
        
        production_data = []
        
        for m_idx, machine_id in enumerate(self.machines):
            if machine and machine != machine_id:
                continue
            
            for shift_type in ["morning", "afternoon", "night"]:
                if shift and shift != shift_type:
                    continue
                
                # Base production metrics
                planned_qty = random.randint(800, 1200)
                
                # Apply operator skill impact
                operator = random.choice(self.operators)
                defect_rate = self.operator_skill.get(operator, 0.02)
                
                # Create production record
                record = {
                    "machine_id": machine_id,
                    "shift": shift_type,
                    "date": target_date.isoformat(),
                    "operator": operator,
                    "mold_id": random.choice(self.molds),
                    "product": random.choice(self.products),
                    "planned_qty": planned_qty,
                    "actual_qty": int(planned_qty * random.uniform(0.85, 1.05)),
                    "defect_rate": defect_rate,
                    "performance_factor": 1.0,
                    "availability": random.uniform(0.75, 0.95)
                }
                
                # Add scenario patterns
                record = self.add_scenario_patterns(record, target_date)
                
                # Calculate good, rework, scrap
                record["scrap_qty"] = int(record["actual_qty"] * record["defect_rate"])
                record["rework_qty"] = int(record["actual_qty"] * 0.02)
                record["good_qty"] = record["actual_qty"] - record["scrap_qty"] - record["rework_qty"]
                
                # Calculate OEE components
                record["oee_availability"] = record["availability"]
                record["oee_performance"] = min(record["actual_qty"] / planned_qty, 1.0) * record.get("performance_factor", 1.0)
                record["oee_quality"] = record["good_qty"] / max(record["actual_qty"], 1)
                record["oee"] = record["oee_availability"] * record["oee_performance"] * record["oee_quality"]
                
                production_data.append(record)
        
        return production_data
    
    def get_downtime_data(self, machine: str = None, start_date: str = None, 
                         end_date: str = None) -> List[Dict]:
        """Generate downtime records"""
        
        downtime_reasons = [
            ("Material Shortage", "supply", 15, 45),
            ("Tool Change", "changeover", 10, 30),
            ("Breakdown", "mechanical", 30, 180),
            ("Quality Hold", "quality", 20, 60),
            ("Operator Break", "planned", 10, 15),
            ("Power Outage", "external", 60, 240),
            ("Maintenance", "planned", 60, 120)
        ]
        
        downtime_data = []
        
        for machine_id in self.machines:
            if machine and machine != machine_id:
                continue
            
            # Generate random downtime events
            num_events = random.randint(2, 8)
            for _ in range(num_events):
                reason, category, min_duration, max_duration = random.choice(downtime_reasons)
                
                downtime_data.append({
                    "id": f"DT_{len(downtime_data)+1:04d}",
                    "machine_id": machine_id,
                    "start_time": datetime.now() - timedelta(hours=random.randint(1, 168)),
                    "duration_minutes": random.randint(min_duration, max_duration),
                    "reason": reason,
                    "category": category,
                    "mttr": random.uniform(20, 60) if category == "mechanical" else None,
                    "technician": f"TECH_{random.randint(1, 5):02d}" if category == "mechanical" else None
                })
        
        return downtime_data
    
    def get_quality_data(self, item: str = None, tool: str = None, 
                        date_range: int = 7) -> List[Dict]:
        """Generate quality inspection data"""
        
        quality_data = []
        defect_types = ["dimensional_variance", "surface_defect", "contamination", 
                       "color_mismatch", "structural_issue"]
        
        for day in range(date_range):
            date = datetime.now() - timedelta(days=day)
            
            for mold in self.molds:
                if tool and tool != mold:
                    continue
                
                for product in self.products:
                    if item and item != product:
                        continue
                    
                    # Generate inspection records
                    inspections = random.randint(10, 30)
                    defects = int(inspections * random.uniform(0.01, 0.05))
                    
                    quality_data.append({
                        "date": date.isoformat(),
                        "mold_id": mold,
                        "product": product,
                        "total_inspected": inspections,
                        "defects_found": defects,
                        "defect_types": {
                            dt: random.randint(0, max(1, defects//3)) 
                            for dt in random.sample(defect_types, min(3, len(defect_types)))
                        },
                        "fpy": (inspections - defects) / inspections if inspections > 0 else 0,
                        "cavity_defects": {
                            f"cavity_{i}": random.uniform(0, 0.1) 
                            for i in range(1, 5)
                        }
                    })
        
        return quality_data
    
    def get_scrap_data(self, machine: str = None, item: str = None, 
                       date_range: int = 30) -> List[Dict]:
        """Generate scrap cost data"""
        
        scrap_data = []
        base_cost_per_kg = 150  # INR per kg
        
        for day in range(date_range):
            date = datetime.now() - timedelta(days=day)
            
            for machine_id in self.machines:
                if machine and machine != machine_id:
                    continue
                
                for product in self.products:
                    if item and item != product:
                        continue
                    
                    scrap_kg = random.uniform(5, 50)
                    scrap_data.append({
                        "date": date.isoformat(),
                        "machine_id": machine_id,
                        "product": product,
                        "scrap_quantity_kg": scrap_kg,
                        "scrap_cost_inr": scrap_kg * base_cost_per_kg,
                        "reason": random.choice(["defect", "startup", "shutdown", "changeover"]),
                        "recoverable": random.choice([True, False])
                    })
        
        return scrap_data
    
    def get_inventory_data(self) -> List[Dict]:
        """Generate inventory status data"""
        
        materials = ["Raw_Material_A", "Raw_Material_B", "Component_X", "Component_Y", "Packaging_Z"]
        inventory = []
        
        for material in materials:
            current_stock = random.uniform(100, 1000)
            min_stock = random.uniform(50, 200)
            max_stock = random.uniform(800, 1500)
            daily_consumption = random.uniform(20, 100)
            
            inventory.append({
                "item_id": material,
                "item_name": material.replace("_", " "),
                "current_stock": current_stock,
                "min_threshold": min_stock,
                "max_threshold": max_stock,
                "unit": "kg",
                "coverage_days": current_stock / daily_consumption if daily_consumption > 0 else 999,
                "reorder_point": min_stock * 1.2,
                "lead_time_days": random.randint(3, 15),
                "supplier": f"Supplier_{random.randint(1, 5)}"
            })
        
        return inventory
    
    def get_historical_data(self, target: str) -> List[Dict]:
        """Get historical data for predictions"""
        
        historical = []
        
        for hours_ago in range(168, 0, -1):  # Last 7 days hourly
            timestamp = datetime.now() - timedelta(hours=hours_ago)
            
            if target == "oee":
                value = 75 + 10 * np.sin(hours_ago / 24) + random.uniform(-5, 5)
            elif target == "downtime":
                value = max(0, 30 + 20 * np.cos(hours_ago / 12) + random.uniform(-10, 10))
            elif target == "quality":
                value = 95 + 3 * np.sin(hours_ago / 48) + random.uniform(-2, 2)
            else:
                value = random.uniform(50, 100)
            
            historical.append({
                "timestamp": timestamp.isoformat(),
                "value": value,
                "shift": self._get_shift(timestamp.hour),
                "day_of_week": timestamp.weekday()
            })
        
        return historical
    
    def get_current_state(self) -> Dict:
        """Get current manufacturing state"""
        
        return {
            "timestamp": datetime.now().isoformat(),
            "machines_running": len([m for m in self.machines if random.random() > 0.2]),
            "average_oee": 75.3,
            "quality_rate": 94.5,
            "planned_output": 10000,
            "actual_output": 8500,
            "operators_present": 45,
            "material_availability": 0.92
        }
    
    def _get_shift(self, hour: int) -> str:
        """Determine shift based on hour"""
        if 6 <= hour < 14:
            return "morning"
        elif 14 <= hour < 22:
            return "afternoon"
        else:
            return "night"
    
    def get_constraints(self) -> Dict:
        """Get production constraints"""
        return {
            "machines": {m: random.choice(["available", "maintenance", "breakdown"]) 
                        for m in self.machines},
            "molds": {m: random.choice(["available", "in_use", "maintenance"]) 
                     for m in self.molds},
            "operators": {"available": 45, "required": 40},
            "materials": self.get_inventory_data()
        }
    
    def get_demand_forecast(self, start_date: str, end_date: str) -> List[Dict]:
        """Get demand forecast"""
        forecast = []
        
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        days = (end - start).days
        
        for day in range(days + 1):
            date = start + timedelta(days=day)
            for product in self.products:
                forecast.append({
                    "date": date.isoformat(),
                    "product": product,
                    "quantity": random.randint(500, 1500),
                    "priority": random.choice(["high", "medium", "low"])
                })
        
        return forecast
    
    def get_production_plan(self, date: str = None) -> Dict:
        """Get production plan"""
        if not date:
            date = datetime.now().strftime("%Y-%m-%d")
        
        return {
            "date": date,
            "shifts": {
                "morning": {p: random.randint(200, 400) for p in self.products},
                "afternoon": {p: random.randint(200, 400) for p in self.products},
                "night": {p: random.randint(150, 350) for p in self.products}
            },
            "machine_allocation": {m: random.choice(self.products) for m in self.machines},
            "mold_schedule": {m: random.choice(self.products) for m in self.molds}
        }
    
    def get_module_data(self, module: str, date_range: int) -> Dict:
        """Get data for specific module"""
        
        module_mapping = {
            "production": self.get_production_data,
            "quality": self.get_quality_data,
            "inventory": self.get_inventory_data,
            "downtime": self.get_downtime_data
        }
        
        if module in module_mapping:
            return module_mapping[module](date_range=date_range)
        
        return {}
    
    def get_wip_data(self) -> List[Dict]:
        """Get Work In Progress data"""
        stages = ["molding", "inspection", "assembly", "packaging", "shipping"]
        wip_data = []
        
        for stage in stages:
            items_in_stage = random.randint(5, 20)
            for i in range(items_in_stage):
                wip_data.append({
                    "stage": stage,
                    "lot_number": f"LOT_{random.randint(1000, 9999)}",
                    "product": random.choice(self.products),
                    "quantity": random.randint(50, 200),
                    "entry_time": (datetime.now() - timedelta(hours=random.randint(1, 48))).isoformat(),
                    "expected_exit": (datetime.now() + timedelta(hours=random.randint(1, 12))).isoformat()
                })
        
        return wip_data
    
    def get_capa_data(self) -> List[Dict]:
        """Get CAPA (Corrective and Preventive Action) data"""
        return [
            {
                "id": f"CAPA_{i:04d}",
                "issue_date": (datetime.now() - timedelta(days=random.randint(1, 30))).isoformat(),
                "description": random.choice(["Defect rate increase", "Process deviation", 
                                            "Customer complaint", "Audit finding"]),
                "status": random.choice(["open", "in_progress", "closed"]),
                "owner": random.choice(self.operators),
                "due_date": (datetime.now() + timedelta(days=random.randint(1, 15))).isoformat(),
                "effectiveness_score": random.uniform(0.6, 1.0) if random.random() > 0.5 else None
            }
            for i in range(1, random.randint(5, 15))
        ]
    
    def get_changeover_data(self, machine: str = None, date: str = None) -> List[Dict]:
        """Get changeover data"""
        changeovers = []
        
        for m in self.machines:
            if machine and machine != m:
                continue
            
            changeovers.append({
                "id": f"CO_{len(changeovers)+1:04d}",
                "machine_id": m,
                "from_product": random.choice(self.products),
                "to_product": random.choice(self.products),
                "planned_duration": random.randint(15, 45),
                "actual_duration": random.randint(12, 60),
                "crew": random.sample(self.operators, k=2),
                "efficiency": random.uniform(0.7, 1.1)
            })
        
        return changeovers
    
    def get_loss_data(self, date_range: int) -> List[Dict]:
        """Get loss data for Pareto analysis"""
        loss_reasons = [
            "Material shortage", "Breakdown", "Changeover", "Quality hold",
            "Operator absence", "Power failure", "Maintenance", "Setup error"
        ]
        
        losses = []
        for reason in loss_reasons:
            losses.append({
                "reason": reason,
                "duration_minutes": random.randint(30, 300),
                "frequency": random.randint(1, 20),
                "cost_impact": random.randint(5000, 50000)
            })
        
        return losses
    
    def get_maintenance_data(self, machine: str = None, window: int = 30) -> List[Dict]:
        """Get maintenance data for MTTR/MTBF calculation"""
        maintenance = []
        
        for m in self.machines:
            if machine and machine != m:
                continue
            
            events = random.randint(2, 10)
            for _ in range(events):
                failure_time = datetime.now() - timedelta(days=random.randint(1, window))
                repair_duration = random.randint(30, 240)
                
                maintenance.append({
                    "machine_id": m,
                    "failure_time": failure_time.isoformat(),
                    "repair_time": (failure_time + timedelta(minutes=repair_duration)).isoformat(),
                    "repair_duration_minutes": repair_duration,
                    "failure_type": random.choice(["mechanical", "electrical", "hydraulic"])
                })
        
        return maintenance
    
    def get_assembly_data(self) -> List[Dict]:
        """Get assembly data for reconciliation"""
        assembly_data = []
        
        for product in self.products:
            for batch in range(1, 6):  # 5 batches
                assembly_data.append({
                    "product": product,
                    "batch_number": f"BATCH_{product}_{batch:03d}",
                    "produced_qty": random.randint(800, 1200),
                    "received_qty": random.randint(750, 1180),
                    "variance": random.randint(-50, 20),
                    "assembly_date": (datetime.now() - timedelta(days=random.randint(1, 7))).isoformat(),
                    "status": random.choice(["reconciled", "pending", "mismatch"]),
                    "risk_score": random.uniform(0.1, 0.9)
                })
        
        return assembly_data
    
    def get_logistics_data(self) -> List[Dict]:
        """Get logistics and dispatch data"""
        logistics_data = []
        
        carriers = ["Carrier_A", "Carrier_B", "Carrier_C", "Express_X", "Local_Y"]
        
        for i in range(20):  # 20 shipments
            gate_in_time = datetime.now() - timedelta(hours=random.randint(1, 48))
            loading_time = random.randint(30, 120)  # minutes
            gate_out_time = gate_in_time + timedelta(minutes=loading_time)
            
            logistics_data.append({
                "shipment_id": f"SHIP_{i+1:04d}",
                "carrier": random.choice(carriers),
                "gate_in_time": gate_in_time.isoformat(),
                "gate_out_time": gate_out_time.isoformat(),
                "loading_time_minutes": loading_time,
                "planned_loading_time": random.randint(45, 90),
                "vehicle_type": random.choice(["truck", "trailer", "small_vehicle"]),
                "lane": f"Lane_{random.randint(1, 5)}",
                "dwell_time_minutes": loading_time + random.randint(-15, 30),
                "sla_minutes": 90,
                "product_weight_kg": random.randint(1000, 5000),
                "delivery_status": random.choice(["on_time", "delayed", "early"])
            })
        
        return logistics_data
    
    def get_transport_data(self) -> List[Dict]:
        """Get transport utilization data"""
        transport_data = []
        
        for i in range(15):
            transport_data.append({
                "route_id": f"ROUTE_{i+1:03d}",
                "transport_type": random.choice(["FTL", "LTL", "courier"]),
                "distance_km": random.randint(50, 500),
                "weight_kg": random.randint(500, 10000),
                "cost_inr": random.randint(5000, 25000),
                "cost_per_kg": random.uniform(2.5, 8.0),
                "utilization_percentage": random.uniform(65, 95),
                "delivery_time_hours": random.randint(4, 24),
                "fuel_cost_inr": random.randint(1500, 6000),
                "carrier_rating": random.uniform(3.5, 5.0)
            })
        
        return transport_data
    
    def get_warehouse_data(self) -> List[Dict]:
        """Get warehouse performance data"""
        zones = ["A", "B", "C", "D"]
        warehouse_data = []
        
        for zone in zones:
            for bin_num in range(1, 21):  # 20 bins per zone
                warehouse_data.append({
                    "zone": zone,
                    "bin_id": f"{zone}-{bin_num:02d}",
                    "occupancy_percentage": random.uniform(30, 95),
                    "item_count": random.randint(0, 50),
                    "abc_classification": random.choice(["A", "B", "C"]),
                    "pick_frequency": random.randint(1, 20),
                    "last_pick_time": (datetime.now() - timedelta(hours=random.randint(1, 168))).isoformat(),
                    "putaway_pending": random.randint(0, 10),
                    "location_accuracy": random.uniform(0.85, 1.0)
                })
        
        return warehouse_data
    
    def get_cycle_count_data(self) -> List[Dict]:
        """Get cycle count data"""
        cycle_count_data = []
        
        for material in ["Raw_Material_A", "Raw_Material_B", "Component_X", "Component_Y", "Packaging_Z"]:
            cycle_count_data.append({
                "item_id": material,
                "system_qty": random.randint(500, 2000),
                "physical_qty": random.randint(480, 2020),
                "variance": random.randint(-50, 50),
                "variance_percentage": random.uniform(-5, 5),
                "count_date": (datetime.now() - timedelta(days=random.randint(1, 30))).isoformat(),
                "counter": f"COUNTER_{random.randint(1, 5)}",
                "status": random.choice(["pending", "approved", "rejected", "investigating"]),
                "adjustment_reason": random.choice(["shrinkage", "system_error", "miscount", "theft"])
            })
        
        return cycle_count_data