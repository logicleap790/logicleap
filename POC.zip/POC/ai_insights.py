"""
AI Insights Engine for Logic Leap
Provides AI-driven insights and recommendations for manufacturing operations
"""

import random
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from collections import defaultdict

class AIInsightsEngine:
    def __init__(self):
        self.confidence_threshold = 0.7
        self.insight_templates = {
            "oee_decline": "OEE has declined by {percentage:.1f}% in the last {period}. Primary contributing factor: {factor}",
            "quality_risk": "Quality metrics show increasing risk. Predicted defect rate: {rate:.2f}% (confidence: {confidence:.0%})",
            "maintenance_alert": "Machine {machine} shows early failure indicators. Recommend preventive maintenance within {hours}h",
            "efficiency_opportunity": "Changeover optimization could improve OEE by {improvement:.1f}% on {machine}",
            "cost_impact": "Current trends project additional costs of ₹{amount:,.0f} if not addressed"
        }
    
    def generate_executive_insights(self, oee_metrics: Dict, plan_vs_actual: Dict, 
                                   top_losses: List[Dict]) -> List[Dict]:
        """Generate AI insights for executive overview"""
        
        insights = []
        
        # OEE Analysis
        if oee_metrics.get("oee", 0) < oee_metrics.get("target_oee", 85):
            gap = oee_metrics.get("target_oee", 85) - oee_metrics.get("oee", 0)
            insights.append({
                "type": "performance_gap",
                "confidence": 0.95,
                "message": f"OEE is {gap:.1f}% below target. Focus on {self._get_weakest_pillar(oee_metrics)}",
                "recommendation": "Implement targeted improvement actions",
                "impact_estimate": {"potential_gain": f"₹{gap * 50000:,.0f}/day"},
                "priority": 1
            })
        
        # Plan vs Actual Analysis
        if abs(plan_vs_actual.get("variance", 0)) > 50:
            variance = plan_vs_actual.get("variance", 0)
            insights.append({
                "type": "plan_variance",
                "confidence": 0.88,
                "message": f"Production variance: {variance:+d} units. {plan_vs_actual.get('variance_reason', 'Unknown cause')}",
                "recommendation": "Review scheduling accuracy and capacity planning",
                "impact_estimate": {"cost_impact": f"₹{abs(variance) * 100:,.0f}"},
                "priority": 2
            })
        
        # Top Losses Analysis
        if top_losses and len(top_losses) > 0:
            top_loss = top_losses[0]
            insights.append({
                "type": "loss_opportunity",
                "confidence": 0.82,
                "message": f"Top loss '{top_loss.get('reason')}' accounts for {top_loss.get('impact_percentage', 0):.1f}% of downtime",
                "recommendation": f"Assign dedicated team to {top_loss.get('owner', 'Production')}",
                "impact_estimate": {"time_savings": f"{top_loss.get('duration_minutes', 0):.0f} min/day"},
                "priority": 1 if top_loss.get("impact_percentage", 0) > 20 else 3
            })
        
        return sorted(insights, key=lambda x: x["priority"])[:5]
    
    def generate_module_insights(self, data_context: Dict) -> Dict:
        """Generate AI insights for specific modules"""
        
        module = data_context.get("module", "general")
        timestamp = data_context.get("timestamp", datetime.now())
        
        insights = {
            "module": module,
            "timestamp": timestamp,
            "insights": [],
            "recommendations": [],
            "confidence_score": random.uniform(0.75, 0.95)
        }
        
        # Module-specific insights
        if module == "production":
            insights["insights"] = [
                "Bottleneck detected at Machine_5 during afternoon shift",
                "Operator skill variance affecting quality on Line 2",
                "Energy consumption 12% higher than benchmark"
            ]
            insights["recommendations"] = [
                "Schedule preventive maintenance for Machine_5",
                "Provide additional training for afternoon shift operators",
                "Implement energy optimization protocols"
            ]
        
        elif module == "quality":
            insights["insights"] = [
                "Defect clustering observed in cavity 3 of MOLD_AN_02",
                "Temperature variation correlates with surface defects",
                "Supplier batch ABC123 shows 2.3x higher defect rate"
            ]
            insights["recommendations"] = [
                "Replace worn tooling in cavity 3",
                "Calibrate temperature controls",
                "Review supplier quality agreement"
            ]
        
        elif module == "inventory":
            insights["insights"] = [
                "Raw Material A approaching stockout in 3 days",
                "WIP aging in inspection stage indicates bottleneck",
                "Seasonal demand pattern suggests inventory buildup needed"
            ]
            insights["recommendations"] = [
                "Expedite Raw Material A procurement",
                "Add inspection capacity or extend hours",
                "Adjust reorder points for seasonal products"
            ]
        
        return insights
    
    def generate_predictions(self, historical_data: List[Dict], target: str, 
                           horizon_hours: int) -> Dict:
        """Generate AI predictions"""
        
        if not historical_data:
            return self._empty_prediction(target, horizon_hours)
        
        # Simple trend analysis (in real implementation, use ML models)
        recent_values = [d.get("value", 0) for d in historical_data[-24:]]  # Last 24 hours
        trend = (recent_values[-1] - recent_values[0]) / len(recent_values) if recent_values else 0
        
        # Project forward
        current_value = recent_values[-1] if recent_values else 50
        predicted_value = current_value + (trend * horizon_hours)
        
        # Add some realistic bounds
        if target == "oee":
            predicted_value = max(0, min(100, predicted_value))
        elif target == "quality":
            predicted_value = max(80, min(100, predicted_value))
        elif target == "downtime":
            predicted_value = max(0, predicted_value)
        
        # Calculate confidence based on data stability
        variance = self._calculate_variance(recent_values) if len(recent_values) > 1 else 10
        confidence = max(0.5, min(0.95, 1 - (variance / 100)))
        
        return {
            "target": target,
            "timestamp": datetime.now(),
            "horizon_hours": horizon_hours,
            "predicted_value": round(predicted_value, 2),
            "confidence_interval": {
                "lower": round(predicted_value - variance, 2),
                "upper": round(predicted_value + variance, 2),
                "confidence": round(confidence, 2)
            },
            "contributing_factors": self._identify_factors(target, historical_data)
        }
    
    def generate_ceo_brief(self, all_data: Dict) -> Dict:
        """Generate 60-second CEO brief"""
        
        production_data = all_data.get("production", [])
        quality_data = all_data.get("quality", [])
        downtime_data = all_data.get("downtime", [])
        
        # Calculate key metrics
        avg_oee = self._calculate_avg_metric(production_data, "oee") * 100
        quality_rate = self._calculate_avg_metric(quality_data, "fpy") * 100
        total_downtime = sum(d.get("duration_minutes", 0) for d in downtime_data)
        
        # Generate executive summary
        summary_lines = [
            f"OEE at {avg_oee:.1f}% ({'above' if avg_oee > 85 else 'below'} target)",
            f"Quality rate: {quality_rate:.1f}%",
            f"Unplanned downtime: {total_downtime:.0f} minutes"
        ]
        
        # Identify key risks
        risks = []
        if avg_oee < 75:
            risks.append({"risk": "Low OEE performance", "impact": "High", "probability": "Current"})
        if total_downtime > 300:
            risks.append({"risk": "Excessive downtime", "impact": "Medium", "probability": "Current"})
        if quality_rate < 95:
            risks.append({"risk": "Quality concerns", "impact": "High", "probability": "Current"})
        
        # Generate recommendations
        actions = []
        if avg_oee < 80:
            actions.append({"action": "Launch OEE improvement initiative", "owner": "Production Manager", "timeline": "This week"})
        if total_downtime > 200:
            actions.append({"action": "Review maintenance schedule", "owner": "Maintenance Head", "timeline": "Immediate"})
        
        return {
            "date": datetime.now(),
            "executive_summary": ". ".join(summary_lines),
            "key_risks": risks,
            "recommended_actions": actions,
            "metrics_snapshot": {
                "oee": avg_oee,
                "quality": quality_rate,
                "availability": 85.2,
                "cost_variance": -2.3
            },
            "explainable_insights": [
                "Primary loss driver: unplanned maintenance",
                "Quality trending downward due to tool wear",
                "Energy costs 8% above benchmark"
            ]
        }
    
    def run_what_if_simulation(self, current_state: Dict, scenario: Dict) -> Dict:
        """Run what-if simulation scenarios"""
        
        scenario_name = scenario.get("name", "Custom Scenario")
        parameters = scenario.get("parameters", {})
        
        # Baseline metrics from current state
        baseline = {
            "oee": current_state.get("average_oee", 75),
            "output": current_state.get("actual_output", 8500),
            "quality": 94.5,
            "cost": 100000  # Base cost in INR
        }
        
        # Apply scenario modifications
        projected = baseline.copy()
        
        if "changeover_reduction" in parameters:
            reduction_pct = parameters["changeover_reduction"]
            projected["oee"] += reduction_pct * 0.3  # 30% of changeover reduction impacts OEE
            projected["output"] += projected["output"] * (reduction_pct / 100) * 0.2
        
        if "extra_crew" in parameters:
            crew_hours = parameters["extra_crew"]
            projected["output"] += crew_hours * 50  # 50 units per crew hour
            projected["cost"] += crew_hours * 500  # 500 INR per crew hour
        
        if "machine_fix" in parameters:
            machines_fixed = parameters["machine_fix"]
            projected["oee"] += machines_fixed * 5  # 5% OEE improvement per machine
            projected["output"] += machines_fixed * 200
            projected["cost"] += machines_fixed * 25000  # 25k INR repair cost
        
        # Ensure realistic bounds
        projected["oee"] = min(95, max(50, projected["oee"]))
        projected["quality"] = min(99.5, max(90, projected["quality"]))
        
        # Calculate deltas
        delta = {metric: projected[metric] - baseline[metric] for metric in baseline}
        
        # Assess risks
        risks = []
        if projected["oee"] > 90:
            risks.append("May stress equipment beyond optimal range")
        if "extra_crew" in parameters and parameters["extra_crew"] > 16:
            risks.append("Overtime fatigue may impact quality")
        if projected["cost"] > baseline["cost"] * 1.2:
            risks.append("Cost increase exceeds 20% threshold")
        
        return {
            "scenario_name": scenario_name,
            "baseline_metrics": baseline,
            "projected_metrics": projected,
            "delta": {k: round(v, 1) for k, v in delta.items()},
            "roi_estimate": round((delta["output"] * 100 - delta["cost"]) / max(delta["cost"], 1), 2),
            "risks": risks,
            "feasibility": "high" if len(risks) == 0 else "medium" if len(risks) <= 2 else "low"
        }
    
    # Helper methods
    def _get_weakest_pillar(self, oee_metrics: Dict) -> str:
        """Identify the weakest OEE pillar"""
        pillars = {
            "availability": oee_metrics.get("availability", 0),
            "performance": oee_metrics.get("performance", 0),
            "quality": oee_metrics.get("quality", 0)
        }
        return min(pillars, key=pillars.get)
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of values"""
        if len(values) < 2:
            return 5.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
        return variance ** 0.5  # Standard deviation
    
    def _identify_factors(self, target: str, historical_data: List[Dict]) -> List[Dict]:
        """Identify contributing factors for predictions"""
        
        factors_map = {
            "oee": [
                {"factor": "shift_pattern", "impact": 0.15},
                {"factor": "maintenance_schedule", "impact": 0.25},
                {"factor": "operator_skill", "impact": 0.10}
            ],
            "quality": [
                {"factor": "material_batch", "impact": 0.20},
                {"factor": "environmental_conditions", "impact": 0.15},
                {"factor": "tool_wear", "impact": 0.30}
            ],
            "downtime": [
                {"factor": "equipment_age", "impact": 0.35},
                {"factor": "workload_intensity", "impact": 0.20},
                {"factor": "maintenance_frequency", "impact": 0.25}
            ]
        }
        
        return factors_map.get(target, [{"factor": "general_trend", "impact": 0.50}])
    
    def _calculate_avg_metric(self, data: List[Dict], metric: str) -> float:
        """Calculate average of a metric from data list"""
        if not data:
            return 0.0
        
        values = [d.get(metric, 0) for d in data if metric in d]
        return sum(values) / len(values) if values else 0.0
    
    def _empty_prediction(self, target: str, horizon_hours: int) -> Dict:
        """Return empty prediction structure"""
        return {
            "target": target,
            "timestamp": datetime.now(),
            "horizon_hours": horizon_hours,
            "predicted_value": 0.0,
            "confidence_interval": {"lower": 0.0, "upper": 0.0, "confidence": 0.0},
            "contributing_factors": []
        }