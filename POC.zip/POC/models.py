"""
Data Models and Pydantic Schemas for Logic Leap API
"""

from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum

# ==================== ENUMS ====================

class ShiftType(str, Enum):
    MORNING = "morning"
    AFTERNOON = "afternoon"
    NIGHT = "night"

class DefectType(str, Enum):
    DIMENSIONAL = "dimensional_variance"
    SURFACE = "surface_defect"
    STRUCTURAL = "structural_issue"
    COLOR = "color_mismatch"
    CONTAMINATION = "contamination"
    OTHER = "other"

class AlertSeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class MachineStatus(str, Enum):
    RUNNING = "running"
    IDLE = "idle"
    MAINTENANCE = "maintenance"
    BREAKDOWN = "breakdown"
    CHANGEOVER = "changeover"

# ==================== OEE MODELS ====================

class OEEMetrics(BaseModel):
    availability: float = Field(..., ge=0, le=100)
    performance: float = Field(..., ge=0, le=100)
    quality: float = Field(..., ge=0, le=100)
    oee: float = Field(..., ge=0, le=100)
    target_oee: float = Field(default=85.0)
    trend_7day: List[float]
    benchmark: float = Field(default=85.0)

class PlanVsActual(BaseModel):
    date: datetime
    planned_quantity: int
    actual_quantity: int
    good_quantity: int
    adherence_percentage: float
    variance: int
    variance_reason: Optional[str] = None
    auto_explanation: Optional[str] = None

class LossItem(BaseModel):
    reason: str
    duration_minutes: float
    frequency: int
    impact_percentage: float
    cumulative_percentage: float
    owner: Optional[str] = None
    root_cause: Optional[str] = None

class ScrapAnalysis(BaseModel):
    machine_id: str
    scrap_percentage: float
    scrap_cost_inr: float
    fpy: float
    defect_types: Dict[str, int]
    trend_data: List[float]

# ==================== PRODUCTION MODELS ====================

class ShiftOutput(BaseModel):
    shift: ShiftType
    date: datetime
    planned: int
    actual: int
    good: int
    rework: int
    scrap: int
    oee: float
    crew: Optional[str] = None
    machine: Optional[str] = None

class DowntimeRecord(BaseModel):
    id: str
    machine_id: str
    start_time: datetime
    end_time: datetime
    duration_minutes: float
    reason: str
    category: str
    mttr: Optional[float] = None
    technician: Optional[str] = None
    photo_url: Optional[str] = None
    voice_note_url: Optional[str] = None

class ChangeoverRecord(BaseModel):
    id: str
    machine_id: str
    from_product: str
    to_product: str
    planned_duration: float
    actual_duration: float
    crew: List[str]
    efficiency: float
    issues: Optional[List[str]] = None

class FirstPassYield(BaseModel):
    item: Optional[str]
    tool: Optional[str]
    fpy_percentage: float
    trend_data: List[float]
    spc_upper_limit: float
    spc_lower_limit: float
    defect_breakdown: Dict[str, float]

# ==================== QUALITY MODELS ====================

class DefectAnalysis(BaseModel):
    tool_id: str
    mold_id: Optional[str]
    total_defects: int
    defect_rate: float
    cavity_heatmap: Dict[str, float]
    top_defects: List[Dict[str, Any]]
    cluster_analysis: Optional[Dict[str, Any]] = None

class ScrapCost(BaseModel):
    period: str
    total_cost_inr: float
    cost_by_machine: Dict[str, float]
    cost_by_item: Dict[str, float]
    recovery_trend: List[float]
    variance_vs_plan: float

class CAPARecord(BaseModel):
    id: str
    issue_date: datetime
    description: str
    status: str
    owner: str
    due_date: datetime
    effectiveness_score: Optional[float] = None
    linked_ncr: Optional[str] = None
    evidence_urls: List[str] = []

# ==================== AI INSIGHTS MODELS ====================

class AIInsight(BaseModel):
    type: str
    confidence: float = Field(..., ge=0, le=1)
    message: str
    recommendation: Optional[str] = None
    impact_estimate: Optional[Dict[str, Any]] = None
    priority: int = Field(..., ge=1, le=5)

class Prediction(BaseModel):
    target: str
    timestamp: datetime
    horizon_hours: int
    predicted_value: float
    confidence_interval: Dict[str, float]
    contributing_factors: List[Dict[str, float]]

class CEOBrief(BaseModel):
    date: datetime
    executive_summary: str
    key_risks: List[Dict[str, Any]]
    recommended_actions: List[Dict[str, Any]]
    metrics_snapshot: Dict[str, float]
    explainable_insights: List[str]

class WhatIfScenario(BaseModel):
    name: str
    parameters: Dict[str, Any]
    constraints: Optional[Dict[str, Any]] = None

class WhatIfResult(BaseModel):
    scenario_name: str
    baseline_metrics: Dict[str, float]
    projected_metrics: Dict[str, float]
    delta: Dict[str, float]
    roi_estimate: Optional[float] = None
    risks: List[str]

# ==================== INVENTORY MODELS ====================

class InventoryAlert(BaseModel):
    item_id: str
    item_name: str
    current_stock: float
    min_threshold: float
    max_threshold: float
    coverage_days: float
    alert_type: str
    reorder_proposal: Optional[Dict[str, Any]] = None

class MaterialAvailability(BaseModel):
    date: datetime
    required_materials: Dict[str, float]
    available_materials: Dict[str, float]
    shortages: List[Dict[str, Any]]
    risk_score: float
    alternate_materials: Optional[List[Dict[str, Any]]] = None

class WIPAging(BaseModel):
    stage: str
    items: List[Dict[str, Any]]
    average_dwell_time: float
    bottleneck_flag: bool
    aging_alerts: List[Dict[str, Any]]

# ==================== SCHEDULER MODELS ====================

class ConstraintPlan(BaseModel):
    start_date: datetime
    end_date: datetime
    machine_allocation: Dict[str, List[Dict[str, Any]]]
    mold_schedule: Dict[str, List[Dict[str, Any]]]
    changeover_windows: List[Dict[str, Any]]
    crew_assignments: Dict[str, List[str]]
    material_requirements: Dict[str, float]
    utilization_percentage: float

class SchedulerScenario(BaseModel):
    name: str
    holiday_surge: Optional[bool] = False
    overtime_hours: Optional[float] = 0
    subcontract_percentage: Optional[float] = 0
    additional_machines: Optional[List[str]] = []
    maintenance_windows: Optional[List[Dict[str, Any]]] = []

# ==================== COMPOSITE MODELS ====================

class ExecutiveOverview(BaseModel):
    oee_snapshot: OEEMetrics
    plan_vs_actual: PlanVsActual
    top_losses: List[LossItem]
    scrap_by_machine: List[ScrapAnalysis]
    ai_insights: List[AIInsight]
    timestamp: datetime

class ModuleHealthStatus(BaseModel):
    module: str
    health_score: float = Field(..., ge=0, le=100)
    status: str
    key_metrics: Dict[str, float]
    alerts: List[Dict[str, Any]]
    ai_brief: str

class DailyBrief(BaseModel):
    date: datetime
    role: str
    highlights: List[str]
    metrics: Dict[str, Any]
    actions_required: List[Dict[str, Any]]
    trend_context: Dict[str, Any]

class ExceptionAlert(BaseModel):
    id: str
    timestamp: datetime
    severity: AlertSeverity
    module: str
    message: str
    owner: Optional[str] = None
    acknowledged: bool = False
    auto_escalate: bool = False
    resolution_eta: Optional[datetime] = None

# ==================== EXPORT MODELS ====================

class ExportRequest(BaseModel):
    module: str
    format: str = Field(default="csv", pattern="^(csv|xlsx|pdf)$")
    date_range: int = Field(default=7, ge=1, le=365)
    filters: Optional[Dict[str, Any]] = None

class ExportResponse(BaseModel):
    file_url: str
    file_size: int
    created_at: datetime
    expires_at: datetime