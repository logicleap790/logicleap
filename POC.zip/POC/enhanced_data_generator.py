"""
Enhanced Data Generator for Logic Leap Manufacturing
Generates comprehensive realistic manufacturing data with complex scenarios
Based on POC_Production.txt patterns and real manufacturing constraints
"""

import random
import json
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path
import csv
from dataclasses import dataclass
from enum import Enum
import math

class ShiftType(Enum):
    MORNING = "morning"  # 6 AM - 2 PM
    AFTERNOON = "afternoon"  # 2 PM - 10 PM  
    NIGHT = "night"  # 10 PM - 6 AM

class SeasonalPeriod(Enum):
    WINTER = "winter"  # Dec-Feb
    SPRING = "spring"  # Mar-May
    MONSOON = "monsoon"  # Jun-Sep
    POST_MONSOON = "post_monsoon"  # Oct-Nov

@dataclass
class OperatorProfile:
    id: str
    skill_level: float  # 0.0 to 1.0
    experience_years: int
    defect_rate: float
    efficiency: float
    preferred_shift: ShiftType
    training_date: datetime
    certification_level: str

@dataclass
class MachineProfile:
    id: str
    model: str
    install_date: datetime
    last_maintenance: datetime
    mtbf_hours: float  # Mean Time Between Failures
    mttr_minutes: float  # Mean Time To Repair
    oee_baseline: float
    energy_consumption_kwh: float
    tooling_wear_rate: float
    capacity_units_per_hour: int

class EnhancedDataGenerator:
    def __init__(self, storage_path: str = "storage"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(exist_ok=True)
        
        # Initialize realistic configurations
        self.setup_manufacturing_environment()
        self.setup_seasonal_patterns()
        self.setup_operators()
        self.setup_machines()
        self.setup_materials()
        self.setup_customers()
        
        # Historical data tracking
        self.historical_data = self.load_historical_data()
        
    def setup_manufacturing_environment(self):
        """Setup manufacturing environment parameters"""
        self.plants = {
            "Plant_Mumbai": {"timezone": "+05:30", "working_days": 320, "shifts": 3},
            "Plant_Chennai": {"timezone": "+05:30", "working_days": 315, "shifts": 2},
            "Plant_Bangalore": {"timezone": "+05:30", "working_days": 310, "shifts": 3}
        }
        
        self.production_lines = {
            "Line_A": {"machines": 4, "capacity": 1000, "type": "injection_molding"},
            "Line_B": {"machines": 3, "capacity": 800, "type": "injection_molding"},
            "Line_C": {"machines": 2, "capacity": 600, "type": "assembly"},
            "Line_D": {"machines": 5, "capacity": 1200, "type": "packaging"}
        }
        
        self.products = {
            "PART_A": {"weight_kg": 0.5, "cycle_time_sec": 45, "material": "PP", "price_inr": 25},
            "PART_B": {"weight_kg": 0.3, "cycle_time_sec": 35, "material": "HDPE", "price_inr": 18},
            "PART_C": {"weight_kg": 0.8, "cycle_time_sec": 60, "material": "ABS", "price_inr": 35},
            "PART_D": {"weight_kg": 0.4, "cycle_time_sec": 40, "material": "PC", "price_inr": 45},
            "PART_E": {"weight_kg": 0.6, "cycle_time_sec": 50, "material": "Nylon", "price_inr": 38}
        }
        
    def setup_seasonal_patterns(self):
        """Setup seasonal manufacturing patterns"""
        self.seasonal_demand = {
            SeasonalPeriod.WINTER: {"multiplier": 1.2, "peak_months": [12, 1, 2]},
            SeasonalPeriod.SPRING: {"multiplier": 0.9, "peak_months": [3, 4, 5]},
            SeasonalPeriod.MONSOON: {"multiplier": 0.7, "peak_months": [6, 7, 8, 9]},
            SeasonalPeriod.POST_MONSOON: {"multiplier": 1.1, "peak_months": [10, 11]}
        }
        
        self.weather_patterns = {
            SeasonalPeriod.MONSOON: {
                "humidity": (80, 95), 
                "temperature": (25, 35),
                "power_instability": 0.3,
                "material_moisture_risk": 0.8
            },
            SeasonalPeriod.WINTER: {
                "humidity": (40, 60),
                "temperature": (15, 25),
                "power_instability": 0.1,
                "material_moisture_risk": 0.2
            }
        }
        
    def setup_operators(self):
        """Setup realistic operator profiles"""
        self.operators = {}
        
        # Experienced operators
        for i in range(1, 6):
            self.operators[f"OP{100+i:02d}"] = OperatorProfile(
                id=f"OP{100+i:02d}",
                skill_level=random.uniform(0.85, 0.98),
                experience_years=random.randint(8, 20),
                defect_rate=random.uniform(0.005, 0.02),
                efficiency=random.uniform(0.92, 1.05),
                preferred_shift=random.choice(list(ShiftType)),
                training_date=datetime.now() - timedelta(days=random.randint(30, 365)),
                certification_level="Senior"
            )
        
        # Medium experience operators
        for i in range(6, 12):
            self.operators[f"OP{100+i:02d}"] = OperatorProfile(
                id=f"OP{100+i:02d}",
                skill_level=random.uniform(0.70, 0.85),
                experience_years=random.randint(3, 8),
                defect_rate=random.uniform(0.02, 0.04),
                efficiency=random.uniform(0.85, 0.95),
                preferred_shift=random.choice(list(ShiftType)),
                training_date=datetime.now() - timedelta(days=random.randint(60, 180)),
                certification_level="Intermediate"
            )
        
        # New operators (higher defect rates as per POC_Production.txt)
        for i in range(15, 18):  # OP115, OP116, OP117
            self.operators[f"OP{100+i:02d}"] = OperatorProfile(
                id=f"OP{100+i:02d}",
                skill_level=random.uniform(0.50, 0.70),
                experience_years=random.randint(0, 3),
                defect_rate=random.uniform(0.045, 0.058),  # From POC_Production.txt
                efficiency=random.uniform(0.75, 0.85),
                preferred_shift=random.choice(list(ShiftType)),
                training_date=datetime.now() - timedelta(days=random.randint(1, 30)),
                certification_level="Trainee"
            )
    
    def setup_machines(self):
        """Setup realistic machine profiles"""
        self.machines = {}
        
        for i in range(1, 11):
            machine_id = f"Machine_{i}"
            install_date = datetime.now() - timedelta(days=random.randint(365, 2555))  # 1-7 years old
            age_factor = (datetime.now() - install_date).days / 365  # Age in years
            
            self.machines[machine_id] = MachineProfile(
                id=machine_id,
                model=f"Injection_Molding_{random.choice(['Pro', 'Elite', 'Standard'])}_{random.randint(100, 500)}",
                install_date=install_date,
                last_maintenance=datetime.now() - timedelta(days=random.randint(1, 30)),
                mtbf_hours=max(50, 200 - (age_factor * 10)),  # Decreases with age
                mttr_minutes=30 + (age_factor * 5),  # Increases with age
                oee_baseline=max(0.6, 0.85 - (age_factor * 0.02)),  # Decreases with age
                energy_consumption_kwh=random.uniform(15, 25),
                tooling_wear_rate=0.001 + (age_factor * 0.0005),
                capacity_units_per_hour=random.randint(80, 120)
            )
    
    def setup_materials(self):
        """Setup material specifications and suppliers"""
        self.materials = {
            "Raw_Material_PP": {
                "supplier": ["Supplier_A", "Supplier_B"],
                "lead_time_days": random.randint(7, 21),
                "cost_per_kg": random.uniform(80, 120),
                "moisture_sensitivity": 0.3,
                "shelf_life_days": 180,
                "quality_variability": 0.05
            },
            "Raw_Material_HDPE": {
                "supplier": ["Supplier_C", "Supplier_D"],
                "lead_time_days": random.randint(5, 14),
                "cost_per_kg": random.uniform(85, 130),
                "moisture_sensitivity": 0.4,
                "shelf_life_days": 150,
                "quality_variability": 0.03
            },
            "Raw_Material_ABS": {
                "supplier": ["Supplier_E", "Supplier_F"],
                "lead_time_days": random.randint(10, 25),
                "cost_per_kg": random.uniform(150, 200),
                "moisture_sensitivity": 0.8,  # High sensitivity
                "shelf_life_days": 120,
                "quality_variability": 0.08
            }
        }
    
    def setup_customers(self):
        """Setup customer profiles and demand patterns"""
        self.customers = {
            "Customer_Automotive": {
                "demand_variability": 0.15,
                "quality_tolerance": 0.01,
                "delivery_sla_days": 3,
                "seasonal_factor": {"winter": 1.3, "monsoon": 0.8},
                "products": ["PART_A", "PART_C", "PART_D"]
            },
            "Customer_Electronics": {
                "demand_variability": 0.25,
                "quality_tolerance": 0.005,
                "delivery_sla_days": 2,
                "seasonal_factor": {"winter": 1.5, "summer": 1.2},
                "products": ["PART_B", "PART_E"]
            },
            "Customer_Consumer_Goods": {
                "demand_variability": 0.35,
                "quality_tolerance": 0.02,
                "delivery_sla_days": 5,
                "seasonal_factor": {"winter": 1.1, "monsoon": 0.9},
                "products": ["PART_A", "PART_B", "PART_C", "PART_D", "PART_E"]
            }
        }
    
    def get_current_season(self, date: datetime = None) -> SeasonalPeriod:
        """Determine current season based on date"""
        if date is None:
            date = datetime.now()
        
        month = date.month
        if month in [12, 1, 2]:
            return SeasonalPeriod.WINTER
        elif month in [3, 4, 5]:
            return SeasonalPeriod.SPRING
        elif month in [6, 7, 8, 9]:
            return SeasonalPeriod.MONSOON
        else:
            return SeasonalPeriod.POST_MONSOON
    
    def apply_scenario_patterns(self, data: Dict, current_date: datetime) -> Dict:
        """Apply realistic manufacturing scenarios from POC_Production.txt"""
        
        # 1. Tool Wear Pattern - MOLD_AN_02 cavity 3 degrades over time
        if current_date >= datetime(2024, 8, 1):
            days_since = (current_date - datetime(2024, 8, 1)).days
            if data.get('mold_id') == 'MOLD_AN_02':
                wear_factor = 0.02 + (0.08 * min(days_since / 14, 1))
                data['cavity_3_defect_rate'] = wear_factor
                data['defect_rate'] = data.get('defect_rate', 0.01) + wear_factor
                data['scenario_flags'] = data.get('scenario_flags', []) + ['tool_wear']
        
        # 2. Monsoon Material Moisture Issues (Aug 15-25)
        season = self.get_current_season(current_date)
        if season == SeasonalPeriod.MONSOON:
            if datetime(2024, 8, 15) <= current_date <= datetime(2024, 8, 25):
                if random.random() < 0.6:  # 60% chance during peak monsoon
                    data['moisture_defect_multiplier'] = 3.0
                    data['defect_rate'] = data.get('defect_rate', 0.01) * 3.0
                    data['scenario_flags'] = data.get('scenario_flags', []) + ['monsoon_moisture']
        
        # 3. Power Quality Issues (2-5 PM in summer months)
        if current_date.month in [4, 5, 6] and 14 <= current_date.hour <= 17:
            data['power_quality_factor'] = 0.75  # Reduced efficiency
            data['voltage_fluctuation'] = random.uniform(0.85, 1.15)
            data['performance_factor'] = data.get('performance_factor', 1.0) * 0.85
            data['scenario_flags'] = data.get('scenario_flags', []) + ['power_issues']
        
        # 4. Maintenance Skip Consequences - Machine_8 failure cascade
        if data.get('machine_id') == 'Machine_8' and current_date >= datetime(2024, 8, 15):
            if current_date.date() == datetime(2024, 8, 18).date():
                # Catastrophic failure on specific date
                data['catastrophic_failure'] = True
                data['downtime_minutes'] = 1080  # 18 hours
                data['repair_cost_inr'] = 150000
                data['scenario_flags'] = data.get('scenario_flags', []) + ['catastrophic_failure']
            elif datetime(2024, 8, 15) <= current_date < datetime(2024, 8, 18):
                # Degrading performance leading up to failure
                days_degrading = (current_date - datetime(2024, 8, 15)).days
                performance_degradation = 0.9 - (days_degrading * 0.1)
                data['performance_factor'] = max(0.5, performance_degradation)
                data['vibration_level'] = 1 + (days_degrading * 0.3)
                data['scenario_flags'] = data.get('scenario_flags', []) + ['machine_degradation']
        
        # 5. Operator Skill Impact
        operator_id = data.get('operator_id')
        if operator_id in self.operators:
            operator = self.operators[operator_id]
            data['operator_defect_rate'] = operator.defect_rate
            data['operator_efficiency'] = operator.efficiency
            data['operator_skill_level'] = operator.skill_level
        
        # 6. Material Batch Variations
        material_batch = data.get('material_batch')
        if material_batch:
            batch_age_days = random.randint(1, 180)
            if batch_age_days > 120:  # Aging material
                data['material_quality_factor'] = max(0.8, 1 - ((batch_age_days - 120) * 0.005))
                data['scenario_flags'] = data.get('scenario_flags', []) + ['aging_material']
        
        # 7. Environmental Conditions
        season_data = self.weather_patterns.get(season, {})
        if season_data:
            humidity_range = season_data.get('humidity', (50, 70))
            temp_range = season_data.get('temperature', (20, 30))
            
            data['humidity_percent'] = random.uniform(*humidity_range)
            data['temperature_celsius'] = random.uniform(*temp_range)
            data['power_instability_risk'] = season_data.get('power_instability', 0.1)
            
            # High humidity affects certain materials
            if data['humidity_percent'] > 80 and data.get('material_type') == 'ABS':
                data['humidity_defect_factor'] = 1.5
                data['scenario_flags'] = data.get('scenario_flags', []) + ['humidity_impact']
        
        return data
    
    def generate_production_record(self, date: datetime, shift: ShiftType, 
                                 machine_id: str, operator_id: str) -> Dict:
        """Generate a single production record with realistic parameters"""
        
        machine = self.machines[machine_id]
        operator = self.operators[operator_id]
        product = random.choice(list(self.products.keys()))
        product_info = self.products[product]
        
        # Base production calculations
        shift_hours = 8
        theoretical_capacity = machine.capacity_units_per_hour * shift_hours
        planned_qty = int(theoretical_capacity * random.uniform(0.85, 0.95))
        
        # Apply operator efficiency
        actual_qty = int(planned_qty * operator.efficiency * random.uniform(0.9, 1.1))
        
        # Calculate defects based on multiple factors
        base_defect_rate = operator.defect_rate
        machine_factor = 1 + (1 - machine.oee_baseline) * 0.5
        defect_rate = base_defect_rate * machine_factor
        
        # Quality calculations
        total_defects = int(actual_qty * defect_rate)
        rework_qty = int(total_defects * 0.3)  # 30% can be reworked
        scrap_qty = total_defects - rework_qty
        good_qty = actual_qty - total_defects
        
        # OEE calculations
        availability = random.uniform(0.75, 0.95)
        performance = min(1.0, actual_qty / planned_qty)
        quality = good_qty / actual_qty if actual_qty > 0 else 0
        oee = availability * performance * quality
        
        # Create base record
        record = {
            "timestamp": date.isoformat(),
            "date": date.date().isoformat(),
            "shift": shift.value,
            "machine_id": machine_id,
            "operator_id": operator_id,
            "product": product,
            "mold_id": f"MOLD_{product[-1]}_{random.randint(1, 3):02d}",
            "material_batch": f"BATCH_{random.randint(1000, 9999)}",
            
            # Production quantities
            "planned_qty": planned_qty,
            "actual_qty": actual_qty,
            "good_qty": good_qty,
            "rework_qty": rework_qty,
            "scrap_qty": scrap_qty,
            
            # Quality metrics
            "defect_rate": defect_rate,
            "fpy": quality * 100,
            "total_defects": total_defects,
            
            # OEE components
            "availability": availability,
            "performance": performance,
            "quality": quality,
            "oee": oee,
            "oee_availability": availability,
            "oee_performance": performance,
            "oee_quality": quality,
            
            # Operational data
            "cycle_time_actual": product_info["cycle_time_sec"] * random.uniform(0.95, 1.1),
            "energy_consumed_kwh": machine.energy_consumption_kwh * shift_hours * random.uniform(0.9, 1.1),
            "downtime_minutes": random.uniform(0, 60) if random.random() < 0.3 else 0,
            
            # Cost data
            "material_cost_inr": actual_qty * product_info["price_inr"] * 0.6,
            "scrap_cost_inr": scrap_qty * product_info["price_inr"],
            "production_cost_inr": actual_qty * product_info["price_inr"] * 0.8,
            
            # Additional metadata
            "plant": "Plant_Mumbai",
            "line": random.choice(list(self.production_lines.keys())),
            "lot_number": f"LOT_{date.strftime('%Y%m%d')}_{machine_id}_{shift.value[:1].upper()}{random.randint(1,99):02d}",
            "scenario_flags": []
        }
        
        # Apply scenario patterns
        record = self.apply_scenario_patterns(record, date)
        
        return record
    
    def generate_comprehensive_production_data(self, days: int = 30) -> List[Dict]:
        """Generate comprehensive production data for analysis"""
        
        all_records = []
        start_date = datetime.now() - timedelta(days=days)
        
        for day in range(days):
            current_date = start_date + timedelta(days=day)
            
            # Skip weekends (optional - manufacturing can run 7 days)
            # if current_date.weekday() >= 5:  # Saturday=5, Sunday=6
            #     continue
            
            # Generate data for each shift
            for shift in ShiftType:
                # Each shift has multiple machines running
                for machine_id in list(self.machines.keys())[:8]:  # Use 8 machines
                    # Assign operator based on shift preference and availability
                    available_operators = [
                        op_id for op_id, op in self.operators.items() 
                        if op.preferred_shift == shift or random.random() < 0.3
                    ]
                    
                    if available_operators:
                        operator_id = random.choice(available_operators)
                        
                        # Set shift timing
                        if shift == ShiftType.MORNING:
                            shift_start = current_date.replace(hour=6, minute=0)
                        elif shift == ShiftType.AFTERNOON:
                            shift_start = current_date.replace(hour=14, minute=0)
                        else:  # NIGHT
                            shift_start = current_date.replace(hour=22, minute=0)
                        
                        record = self.generate_production_record(
                            shift_start, shift, machine_id, operator_id
                        )
                        all_records.append(record)
        
        return all_records
    
    def generate_quality_inspection_data(self, days: int = 30) -> List[Dict]:
        """Generate detailed quality inspection data"""
        
        inspection_records = []
        defect_types = [
            "dimensional_variance", "surface_defect", "color_mismatch", 
            "contamination", "structural_issue", "flash", "sink_marks",
            "warpage", "short_shot", "burn_marks"
        ]
        
        start_date = datetime.now() - timedelta(days=days)
        
        for day in range(days):
            current_date = start_date + timedelta(days=day)
            
            # Multiple inspection batches per day
            for batch in range(3):  # 3 inspection batches per day
                inspection_time = current_date + timedelta(hours=8*batch + random.randint(0, 4))
                
                for product in self.products.keys():
                    sample_size = random.randint(50, 200)
                    defects_found = int(sample_size * random.uniform(0.01, 0.05))
                    
                    # Distribute defects by type
                    defect_breakdown = {}
                    remaining_defects = defects_found
                    
                    for defect_type in random.sample(defect_types, min(4, len(defect_types))):
                        if remaining_defects > 0:
                            count = random.randint(0, min(remaining_defects, defects_found//3))
                            defect_breakdown[defect_type] = count
                            remaining_defects -= count
                    
                    # Cavity-specific data for injection molding
                    cavity_defects = {}
                    for cavity in range(1, 5):  # 4-cavity mold
                        cavity_defects[f"cavity_{cavity}"] = random.uniform(0, 0.1)
                    
                    inspection_record = {
                        "inspection_id": f"INS_{current_date.strftime('%Y%m%d')}_{batch:02d}_{product}",
                        "date": inspection_time.isoformat(),
                        "product": product,
                        "mold_id": f"MOLD_{product[-1]}_{random.randint(1, 3):02d}",
                        "inspector": f"QC_{random.randint(1, 5):02d}",
                        "shift": "morning" if inspection_time.hour < 14 else "afternoon" if inspection_time.hour < 22 else "night",
                        
                        "total_inspected": sample_size,
                        "defects_found": defects_found,
                        "defect_rate": (defects_found / sample_size) * 100,
                        "fpy": ((sample_size - defects_found) / sample_size),
                        
                        "defect_types": defect_breakdown,
                        "cavity_defects": cavity_defects,
                        
                        "measurement_data": {
                            "dimensions": [random.uniform(9.8, 10.2) for _ in range(5)],
                            "weight_g": [random.uniform(4.8, 5.2) for _ in range(5)],
                            "hardness": random.uniform(85, 95),
                            "surface_roughness": random.uniform(0.5, 2.0)
                        },
                        
                        "environmental_conditions": {
                            "temperature": random.uniform(20, 30),
                            "humidity": random.uniform(40, 80),
                            "pressure": random.uniform(1010, 1020)
                        }
                    }
                    
                    inspection_records.append(inspection_record)
        
        return inspection_records
    
    def save_generated_data(self, filename: str, data: List[Dict]):
        """Save generated data to storage"""
        filepath = self.storage_path / filename
        
        with open(filepath, 'w', newline='') as csvfile:
            if data:
                fieldnames = data[0].keys()
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for row in data:
                    # Handle nested dictionaries and lists
                    flattened_row = {}
                    for key, value in row.items():
                        if isinstance(value, (dict, list)):
                            flattened_row[key] = json.dumps(value)
                        else:
                            flattened_row[key] = value
                    writer.writerow(flattened_row)
        
        return filepath
    
    def load_historical_data(self) -> Dict:
        """Load any existing historical data"""
        try:
            hist_file = self.storage_path / "historical_data.json"
            if hist_file.exists():
                with open(hist_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            print(f"Could not load historical data: {e}")
        
        return {
            "production": [],
            "quality": [],
            "maintenance": [],
            "energy": []
        }