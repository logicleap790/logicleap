"""
Analytics Engine for Logic Leap
Handles all analytical computations and metrics
"""

import json
import csv
import io
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from collections import defaultdict
import statistics
import pandas as pd
from pathlib import Path

class AnalyticsEngine:
    def __init__(self, storage_path: str = "storage"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(exist_ok=True)
        self.alerts = []
        self.alert_counter = 0
    
    def create_pareto_analysis(self, loss_data: List[Dict], top_n: int = 10) -> Dict:
        """Create Pareto analysis of losses"""
        
        # Sort by impact
        sorted_losses = sorted(loss_data, key=lambda x: x.get("cost_impact", 0), reverse=True)
        
        total_impact = sum(l.get("cost_impact", 0) for l in sorted_losses)
        results = []
        cumulative = 0
        
        for loss in sorted_losses[:top_n]:
            impact_pct = (loss.get("cost_impact", 0) / total_impact * 100) if total_impact > 0 else 0
            cumulative += impact_pct
            
            results.append({
                "reason": loss.get("reason"),
                "duration_minutes": loss.get("duration_minutes", 0),
                "frequency": loss.get("frequency", 0),
                "cost_impact": loss.get("cost_impact", 0),
                "impact_percentage": round(impact_pct, 1),
                "cumulative_percentage": round(cumulative, 1)
            })
        
        return {"pareto_analysis": results, "total_impact": total_impact}
    
    def calculate_mttr_mtbf(self, maintenance_data: List[Dict]) -> Dict:
        """Calculate MTTR and MTBF metrics"""
        
        machine_metrics = defaultdict(lambda: {"failures": [], "repairs": []})
        
        for record in maintenance_data:
            machine = record.get("machine_id")
            if machine:
                machine_metrics[machine]["failures"].append(
                    datetime.fromisoformat(record.get("failure_time"))
                )
                machine_metrics[machine]["repairs"].append(
                    record.get("repair_duration_minutes", 0)
                )
        
        results = {}
        for machine, data in machine_metrics.items():
            mttr = statistics.mean(data["repairs"]) if data["repairs"] else 0
            
            # Calculate MTBF
            if len(data["failures"]) > 1:
                sorted_failures = sorted(data["failures"])
                time_between = []
                for i in range(1, len(sorted_failures)):
                    delta = (sorted_failures[i] - sorted_failures[i-1]).total_seconds() / 3600
                    time_between.append(delta)
                mtbf = statistics.mean(time_between) if time_between else 0
            else:
                mtbf = 720  # Default 30 days
            
            results[machine] = {
                "mttr_minutes": round(mttr, 1),
                "mtbf_hours": round(mtbf, 1),
                "health_score": self._calculate_health_score(mttr, mtbf)
            }
        
        return results
    
    def create_loss_tree(self, production_data: List[Dict]) -> Dict:
        """Create availability, performance, quality loss tree"""
        
        oee_metrics = self.calculate_oee(production_data)
        
        availability_loss = 100 - oee_metrics["availability"]
        performance_loss = 100 - oee_metrics["performance"]
        quality_loss = 100 - oee_metrics["quality"]
        
        return {
            "total_oee_loss": round(100 - oee_metrics["oee"], 1),
            "availability_losses": {
                "percentage": round(availability_loss, 1),
                "breakdown": {
                    "planned_maintenance": round(availability_loss * 0.2, 1),
                    "breakdowns": round(availability_loss * 0.4, 1),
                    "changeovers": round(availability_loss * 0.3, 1),
                    "other": round(availability_loss * 0.1, 1)
                }
            },
            "performance_losses": {
                "percentage": round(performance_loss, 1),
                "breakdown": {
                    "speed_loss": round(performance_loss * 0.5, 1),
                    "minor_stops": round(performance_loss * 0.3, 1),
                    "startup_losses": round(performance_loss * 0.2, 1)
                }
            },
            "quality_losses": {
                "percentage": round(quality_loss, 1),
                "breakdown": {
                    "defects": round(quality_loss * 0.6, 1),
                    "rework": round(quality_loss * 0.3, 1),
                    "startup_rejects": round(quality_loss * 0.1, 1)
                }
            }
        }
    
    def check_inventory_alerts(self, inventory_data: List[Dict]) -> List[Dict]:
        """Check for inventory min/max alerts"""
        
        alerts = []
        
        for item in inventory_data:
            current = item.get("current_stock", 0)
            min_threshold = item.get("min_threshold", 0)
            max_threshold = item.get("max_threshold", float('inf'))
            
            if current < min_threshold:
                alerts.append({
                    "item_id": item.get("item_id"),
                    "item_name": item.get("item_name"),
                    "current_stock": current,
                    "min_threshold": min_threshold,
                    "max_threshold": max_threshold,
                    "coverage_days": item.get("coverage_days", 0),
                    "alert_type": "below_minimum",
                    "reorder_proposal": {
                        "quantity": max_threshold - current,
                        "supplier": item.get("supplier"),
                        "lead_time": item.get("lead_time_days", 7)
                    }
                })
            elif current > max_threshold:
                alerts.append({
                    "item_id": item.get("item_id"),
                    "item_name": item.get("item_name"),
                    "current_stock": current,
                    "min_threshold": min_threshold,
                    "max_threshold": max_threshold,
                    "coverage_days": item.get("coverage_days", 999),
                    "alert_type": "above_maximum"
                })
        
        return alerts
    
    def check_material_availability(self, inventory_data: List[Dict], 
                                   production_plan: Dict) -> Dict:
        """Check material availability against production plan"""
        
        # Calculate required materials
        required = defaultdict(float)
        for shift, products in production_plan.get("shifts", {}).items():
            for product, qty in products.items():
                # Simplified BOM calculation
                required["Raw_Material_A"] += qty * 0.5
                required["Raw_Material_B"] += qty * 0.3
                required["Component_X"] += qty * 0.2
        
        # Check availability
        available = {item["item_id"]: item["current_stock"] for item in inventory_data}
        shortages = []
        
        for material, req_qty in required.items():
            avail_qty = available.get(material, 0)
            if avail_qty < req_qty:
                shortages.append({
                    "material": material,
                    "required": req_qty,
                    "available": avail_qty,
                    "shortage": req_qty - avail_qty,
                    "impact": "production_delay"
                })
        
        risk_score = len(shortages) / max(len(required), 1) * 100
        
        return {
            "date": datetime.now(),
            "required_materials": dict(required),
            "available_materials": available,
            "shortages": shortages,
            "risk_score": round(risk_score, 1)
        }
    
    def analyze_wip_aging(self, wip_data: List[Dict]) -> List[Dict]:
        """Analyze WIP aging by stage"""
        
        stage_analysis = defaultdict(lambda: {"items": [], "dwell_times": []})
        
        for item in wip_data:
            stage = item.get("stage")
            entry_time = datetime.fromisoformat(item.get("entry_time"))
            dwell_time = (datetime.now() - entry_time).total_seconds() / 3600
            
            stage_analysis[stage]["items"].append(item)
            stage_analysis[stage]["dwell_times"].append(dwell_time)
        
        results = []
        for stage, data in stage_analysis.items():
            avg_dwell = statistics.mean(data["dwell_times"]) if data["dwell_times"] else 0
            
            results.append({
                "stage": stage,
                "items": data["items"],
                "average_dwell_time": round(avg_dwell, 1),
                "bottleneck_flag": avg_dwell > 24,  # Flag if > 24 hours
                "aging_alerts": [item for item in data["items"] 
                               if (datetime.now() - datetime.fromisoformat(item["entry_time"])).days > 2]
            })
        
        return results
    
    def create_constraint_plan(self, constraints: Dict, demand: List[Dict]) -> Dict:
        """Create constraint-aware production plan"""
        
        # Simple constraint planning logic
        available_machines = [m for m, status in constraints.get("machines", {}).items() 
                            if status == "available"]
        available_molds = [m for m, status in constraints.get("molds", {}).items() 
                         if status == "available"]
        
        # Allocate production
        plan = {
            "start_date": datetime.now(),
            "end_date": datetime.now() + timedelta(days=7),
            "machine_allocation": {},
            "mold_schedule": {},
            "changeover_windows": [],
            "crew_assignments": {},
            "material_requirements": {},
            "utilization_percentage": 0
        }
        
        # Simple allocation logic
        for i, machine in enumerate(available_machines):
            if i < len(demand):
                plan["machine_allocation"][machine] = [{
                    "product": demand[i]["product"],
                    "quantity": demand[i]["quantity"],
                    "start": datetime.now() + timedelta(hours=i*8),
                    "end": datetime.now() + timedelta(hours=(i+1)*8)
                }]
        
        plan["utilization_percentage"] = len(plan["machine_allocation"]) / len(constraints.get("machines", {})) * 100
        
        return plan
    
    def evaluate_scenario(self, base_plan: Dict, scenario: Dict) -> Dict:
        """Evaluate production scenario"""
        
        # Simulate scenario impact
        baseline_output = sum(sum(qty for qty in shift.values()) 
                            for shift in base_plan.get("shifts", {}).values())
        
        # Apply scenario modifiers
        modifier = 1.0
        if scenario.get("overtime_hours"):
            modifier += scenario["overtime_hours"] / 8 * 0.8  # 80% efficiency in overtime
        if scenario.get("holiday_surge"):
            modifier *= 1.2
        if scenario.get("subcontract_percentage"):
            modifier += scenario["subcontract_percentage"] / 100
        
        projected_output = baseline_output * modifier
        
        return {
            "scenario_name": scenario.get("name", "Custom"),
            "baseline_output": baseline_output,
            "projected_output": round(projected_output),
            "delta_percentage": round((projected_output - baseline_output) / baseline_output * 100, 1),
            "cost_impact": round(projected_output * 50, 2),  # Simplified cost calculation
            "feasibility": "high" if modifier < 1.3 else "medium"
        }
    
    def get_exceptions(self, severity: Optional[str] = None, 
                      acknowledged: bool = False) -> List[Dict]:
        """Get system exceptions and alerts"""
        
        # Generate some sample exceptions
        if not self.alerts:
            self.alerts = [
                {
                    "id": f"ALERT_{i:04d}",
                    "timestamp": datetime.now() - timedelta(hours=i),
                    "severity": ["critical", "high", "medium", "low"][i % 4],
                    "module": ["production", "quality", "inventory"][i % 3],
                    "message": f"Alert message {i}",
                    "acknowledged": False
                }
                for i in range(5)
            ]
        
        filtered = self.alerts
        if severity:
            filtered = [a for a in filtered if a["severity"] == severity]
        if not acknowledged:
            filtered = [a for a in filtered if not a["acknowledged"]]
        
        return filtered
    
    def acknowledge_alert(self, alert_id: str) -> Dict:
        """Acknowledge an alert"""
        
        for alert in self.alerts:
            if alert["id"] == alert_id:
                alert["acknowledged"] = True
                return {"status": "success", "alert_id": alert_id}
        
        return {"status": "error", "message": "Alert not found"}
    
    def generate_daily_brief(self, all_metrics: Dict, role: str) -> Dict:
        """Generate role-based daily brief"""
        
        role_highlights = {
            "executive": ["OEE below target", "Quality issues in Machine 5", "Material shortage risk"],
            "production": ["Changeover delays", "Operator allocation", "Machine 8 maintenance due"],
            "quality": ["Defect rate trending up", "CAPA overdue", "Inspection backlog"]
        }
        
        return {
            "date": datetime.now(),
            "role": role,
            "highlights": role_highlights.get(role, ["General updates"]),
            "metrics": {
                "oee": 75.3,
                "quality": 94.5,
                "delivery": 89.2
            },
            "actions_required": [
                {"action": "Review production plan", "due": "Today 2 PM"},
                {"action": "Approve maintenance schedule", "due": "Tomorrow"}
            ],
            "trend_context": {
                "week_over_week": "+2.3%",
                "month_over_month": "-1.2%"
            }
        }
    
    def export_data(self, data: Any, format: str) -> Dict:
        """Export data in specified format"""
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"export_{timestamp}.{format}"
        filepath = self.storage_path / filename
        
        if format == "csv":
            # Convert to CSV
            if isinstance(data, list) and data:
                df = pd.DataFrame(data)
                df.to_csv(filepath, index=False)
        elif format == "xlsx":
            # Convert to Excel
            if isinstance(data, list) and data:
                df = pd.DataFrame(data)
                df.to_excel(filepath, index=False)
        else:
            # JSON format
            with open(filepath, 'w') as f:
                json.dump(data, f, default=str, indent=2)
        
        return {
            "file_url": f"/downloads/{filename}",
            "file_size": filepath.stat().st_size if filepath.exists() else 0,
            "created_at": datetime.now(),
            "expires_at": datetime.now() + timedelta(days=7)
        }
    
    # Helper methods
    def _empty_oee_metrics(self) -> Dict:
        return {
            "availability": 0, "performance": 0, "quality": 0, "oee": 0,
            "target_oee": 85.0, "trend_7day": [], "benchmark": 85.0
        }
    
    def _empty_plan_vs_actual(self) -> Dict:
        return {
            "date": datetime.now(),
            "planned_quantity": 0,
            "actual_quantity": 0,
            "good_quantity": 0,
            "adherence_percentage": 0,
            "variance": 0
        }
    
    def _calculate_trend(self, data: List[Dict], metric: str, days: int) -> List[float]:
        """Calculate trend for a metric"""
        trend = []
        for i in range(min(days, len(data))):
            value = data[i].get(metric, 0)
            if metric == "oee":
                value *= 100
            trend.append(round(value, 1))
        return trend
    
    def _explain_variance(self, variance: int, data: List[Dict]) -> str:
        """Auto-explain production variance"""
        if variance > 0:
            return f"Production exceeded plan by {abs(variance)} units due to improved efficiency"
        elif variance < 0:
            reasons = []
            if any(d.get("catastrophic_failure") for d in data):
                reasons.append("machine failure")
            if any(d.get("power_quality_factor", 1) < 1 for d in data):
                reasons.append("power quality issues")
            if any(d.get("moisture_defect_multiplier", 1) > 1 for d in data):
                reasons.append("material moisture issues")
            
            reason_str = ", ".join(reasons) if reasons else "various factors"
            return f"Production short by {abs(variance)} units due to {reason_str}"
        return "Production met plan exactly"
    
    def _identify_variance_reason(self, data: List[Dict]) -> str:
        """Identify primary variance reason"""
        if any(d.get("catastrophic_failure") for d in data):
            return "Equipment failure"
        if any(d.get("moisture_defect_multiplier", 1) > 2 for d in data):
            return "Material quality issue"
        if any(d.get("power_quality_factor", 1) < 0.9 for d in data):
            return "Power supply issue"
        return "Normal variation"
    
    def _assign_owner(self, reason: str) -> str:
        """Assign owner based on loss reason"""
        ownership_map = {
            "Material": "Supply Chain",
            "Breakdown": "Maintenance",
            "Quality": "Quality Team",
            "Changeover": "Production",
            "Power": "Facilities"
        }
        
        for key, owner in ownership_map.items():
            if key.lower() in reason.lower():
                return owner
        return "Production Manager"
    
    def _identify_root_cause(self, reason: str) -> str:
        """Identify root cause for loss reason"""
        root_cause_map = {
            "Material": "Supplier delay or inventory planning gap",
            "Breakdown": "Preventive maintenance gap or component wear",
            "Quality": "Process variation or operator training",
            "Changeover": "Setup procedure or tool availability",
            "Power": "Grid instability or peak load management"
        }
        
        for key, cause in root_cause_map.items():
            if key.lower() in reason.lower():
                return cause
        return "Under investigation"
    
    def _generate_trend_data(self) -> List[float]:
        """Generate sample trend data"""
        import random
        return [random.uniform(1, 5) for _ in range(7)]
    
    def _get_oee_color(self, oee: float) -> str:
        """Get color coding for OEE value"""
        if oee >= 85:
            return "green"
        elif oee >= 70:
            return "yellow"
        elif oee >= 60:
            return "orange"
        else:
            return "red"
    
    def _calculate_shift_oee(self, data: Dict) -> float:
        """Calculate OEE for shift data"""
        if not data or data.get("actual", 0) == 0:
            return 0
        
        availability = 0.9  # Assumed
        performance = min(data.get("actual", 0) / max(data.get("planned", 1), 1), 1)
        quality = data.get("good", 0) / max(data.get("actual", 1), 1)
        
        return round(availability * performance * quality * 100, 1)
    
    def _calculate_mttr_trend(self, downtime_data: List[Dict]) -> List[float]:
        """Calculate MTTR trend over time"""
        # Group by day and calculate daily MTTR
        daily_mttr = defaultdict(list)
        
        for record in downtime_data:
            if record.get("duration_minutes"):
                date = datetime.fromisoformat(record.get("start_time", datetime.now().isoformat())).date()
                daily_mttr[date].append(record["duration_minutes"])
        
        trend = []
        for date in sorted(daily_mttr.keys())[-7:]:
            if daily_mttr[date]:
                trend.append(round(statistics.mean(daily_mttr[date]), 1))
        
        return trend
    
    def _identify_setup_issues(self, changeover_data: List[Dict]) -> List[str]:
        """Identify setup issues from changeover data"""
        issues = []
        
        for changeover in changeover_data:
            if changeover.get("efficiency", 1) < 0.8:
                issues.append(f"Slow changeover on {changeover.get('machine_id')}")
            if changeover.get("actual_duration", 0) > changeover.get("planned_duration", 0) * 1.5:
                issues.append(f"Major delay on {changeover.get('machine_id')}")
        
        return list(set(issues))[:5]  # Return top 5 unique issues
    
    def _get_top_defects(self, tool: str, quality_data: List[Dict]) -> List[Dict]:
        """Get top defects for a specific tool"""
        defect_counts = defaultdict(int)
        
        for record in quality_data:
            if record.get("mold_id") == tool:
                for defect_type, count in record.get("defect_types", {}).items():
                    defect_counts[defect_type] += count
        
        top_defects = sorted(defect_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return [{"type": defect, "count": count} for defect, count in top_defects]
    
    def _calculate_health_score(self, mttr: float, mtbf: float) -> float:
        """Calculate machine health score based on MTTR and MTBF"""
        # Normalize scores (lower MTTR is better, higher MTBF is better)
        mttr_score = max(0, 100 - (mttr / 60 * 20))  # Normalize to 0-100
        mtbf_score = min(100, mtbf / 10)  # Normalize to 0-100
        
        # Weight: 40% MTTR, 60% MTBF
        return round(mttr_score * 0.4 + mtbf_score * 0.6, 1)
    
    # ==================== ASSEMBLY RECONCILIATION METHODS ====================
    
    def analyze_fg_assembly_mismatch(self, production_data: List[Dict], 
                                    assembly_data: List[Dict]) -> Dict:
        """Analyze FG to Assembly mismatch"""
        
        mismatches = []
        total_variance = 0
        
        # Group production by product and batch
        prod_by_batch = defaultdict(int)
        for prod in production_data:
            batch_key = f"{prod.get('product', 'Unknown')}_{prod.get('date', '')[:10]}"
            prod_by_batch[batch_key] += prod.get("good_qty", 0)
        
        # Compare with assembly data
        for assembly in assembly_data:
            batch_key = f"{assembly.get('product', 'Unknown')}_{assembly.get('assembly_date', '')[:10]}"
            produced = prod_by_batch.get(batch_key, 0)
            received = assembly.get("received_qty", 0)
            variance = received - produced
            total_variance += abs(variance)
            
            if abs(variance) > 10:  # Significant mismatch
                risk_score = min(1.0, abs(variance) / max(produced, 1))
                mismatches.append({
                    "product": assembly.get("product"),
                    "batch": assembly.get("batch_number"),
                    "produced": produced,
                    "received": received,
                    "variance": variance,
                    "variance_percentage": (variance / max(produced, 1) * 100) if produced > 0 else 0,
                    "risk_score": round(risk_score, 2),
                    "tolerance_breach": abs(variance) > produced * 0.05,
                    "status": assembly.get("status", "pending")
                })
        
        return {
            "total_mismatches": len(mismatches),
            "total_variance": total_variance,
            "mismatches": sorted(mismatches, key=lambda x: abs(x["variance"]), reverse=True),
            "reconciliation_rate": (len(assembly_data) - len(mismatches)) / max(len(assembly_data), 1) * 100
        }
    
    def get_assembly_issue_details(self, item: Optional[str], batch: Optional[str], 
                                  machine: Optional[str]) -> Dict:
        """Get detailed assembly issue drilldown"""
        
        # Mock detailed analysis based on filters
        issues = []
        
        if item:
            issues.append({
                "issue_type": "quantity_variance",
                "item": item,
                "batch": batch or f"BATCH_{item}_001",
                "machine": machine or "Machine_5",
                "variance": random.randint(-50, 20),
                "audit_trail": [
                    {"step": "production", "qty": 1000, "timestamp": datetime.now().isoformat()},
                    {"step": "inspection", "qty": 985, "timestamp": (datetime.now() + timedelta(hours=2)).isoformat()},
                    {"step": "assembly", "qty": 980, "timestamp": (datetime.now() + timedelta(hours=4)).isoformat()}
                ],
                "assigned_to": "store" if random.random() > 0.5 else "production",
                "comments": [
                    {"user": "inspector", "comment": "Quality hold applied", "timestamp": datetime.now().isoformat()},
                    {"user": "supervisor", "comment": "Under investigation", "timestamp": datetime.now().isoformat()}
                ]
            })
        
        return {
            "item": item,
            "batch": batch,
            "machine": machine,
            "issues": issues,
            "total_issues": len(issues),
            "resolution_status": "in_progress"
        }
    
    def reconcile_assembly_data(self, reconcile_data: Dict) -> Dict:
        """Reconcile assembly mismatch"""
        
        batch_number = reconcile_data.get("batch_number")
        adjustment_qty = reconcile_data.get("adjustment_qty", 0)
        reason = reconcile_data.get("reason", "Manual adjustment")
        
        # Mock reconciliation process
        return {
            "batch_number": batch_number,
            "adjustment_applied": adjustment_qty,
            "reason": reason,
            "reconciled_by": "system_user",
            "reconciliation_time": datetime.now().isoformat(),
            "status": "completed",
            "approval_required": abs(adjustment_qty) > 100
        }
    
    def calculate_release_recommendation(self, wip_data: List[Dict], 
                                       production_plan: Dict) -> Dict:
        """Calculate recommended release quantities"""
        
        recommendations = []
        
        # Group WIP by stage
        wip_by_stage = defaultdict(list)
        for wip in wip_data:
            wip_by_stage[wip.get("stage")].append(wip)
        
        # Calculate release recommendations
        for stage, items in wip_by_stage.items():
            total_qty = sum(item.get("quantity", 0) for item in items)
            avg_dwell = sum((datetime.now() - datetime.fromisoformat(item.get("entry_time"))).total_seconds() / 3600 
                          for item in items) / max(len(items), 1)
            
            # Simple release logic
            if stage == "molding" and total_qty > 500:
                recommended_release = min(total_qty, 800)
            elif stage == "inspection" and avg_dwell > 24:
                recommended_release = total_qty * 0.8
            else:
                recommended_release = total_qty * 0.6
            
            recommendations.append({
                "stage": stage,
                "current_wip": total_qty,
                "recommended_release": int(recommended_release),
                "buffer_logic": "min_max_based",
                "takt_consideration": True,
                "approval_workflow": recommended_release > 1000
            })
        
        return {
            "recommendations": recommendations,
            "total_wip": sum(item.get("quantity", 0) for item in wip_data),
            "release_priority": "high" if any(r["recommended_release"] > 500 for r in recommendations) else "medium"
        }
    
    def get_lot_traceability(self, lot_number: str) -> Dict:
        """Get complete traceability for a lot"""
        
        return {
            "lot_number": lot_number,
            "traceability": {
                "mold": f"MOLD_AN_{random.randint(1, 3):02d}",
                "operator": f"OP{random.randint(101, 117)}",
                "shift": random.choice(["morning", "afternoon", "night"]),
                "machine": f"Machine_{random.randint(1, 10)}",
                "qc_inspector": f"QC_{random.randint(1, 5):02d}",
                "production_date": (datetime.now() - timedelta(days=random.randint(1, 30))).isoformat(),
                "material_batch": f"MAT_{random.randint(1000, 9999)}",
                "quality_status": "passed",
                "customer_delivery": (datetime.now() + timedelta(days=random.randint(1, 7))).isoformat()
            },
            "genealogy": {
                "parent_lots": [f"LOT_{random.randint(1000, 9999)}" for _ in range(2)],
                "child_lots": [f"LOT_{random.randint(1000, 9999)}" for _ in range(3)],
                "supplier_info": f"Supplier_{random.randint(1, 5)}"
            }
        }
    
    # ==================== LOGISTICS METHODS ====================
    
    def analyze_dispatch_receipt(self, logistics_data: List[Dict]) -> Dict:
        """Analyze dispatch and receipt performance"""
        
        total_shipments = len(logistics_data)
        sla_breaches = sum(1 for l in logistics_data if l.get("dwell_time_minutes", 0) > l.get("sla_minutes", 90))
        
        avg_dwell = statistics.mean([l.get("dwell_time_minutes", 0) for l in logistics_data]) if logistics_data else 0
        
        # Analyze by lane
        lane_analysis = defaultdict(lambda: {"shipments": 0, "avg_dwell": 0, "sla_breaches": 0})
        for shipment in logistics_data:
            lane = shipment.get("lane", "Unknown")
            lane_analysis[lane]["shipments"] += 1
            lane_analysis[lane]["avg_dwell"] += shipment.get("dwell_time_minutes", 0)
            if shipment.get("dwell_time_minutes", 0) > shipment.get("sla_minutes", 90):
                lane_analysis[lane]["sla_breaches"] += 1
        
        # Calculate averages
        for lane_data in lane_analysis.values():
            if lane_data["shipments"] > 0:
                lane_data["avg_dwell"] /= lane_data["shipments"]
        
        return {
            "total_shipments": total_shipments,
            "avg_dwell_time": round(avg_dwell, 1),
            "sla_breach_rate": round(sla_breaches / max(total_shipments, 1) * 100, 1),
            "on_time_delivery": round((total_shipments - sla_breaches) / max(total_shipments, 1) * 100, 1),
            "lane_analysis": dict(lane_analysis),
            "alerts": [{"lane": lane, "issue": "High dwell time"} 
                      for lane, data in lane_analysis.items() if data["avg_dwell"] > 120]
        }
    
    def analyze_late_idle_loss(self, logistics_data: List[Dict]) -> Dict:
        """Analyze late and idle time losses"""
        
        late_shipments = [l for l in logistics_data if l.get("delivery_status") == "delayed"]
        idle_time_total = sum(max(0, l.get("dwell_time_minutes", 0) - l.get("planned_loading_time", 60)) 
                            for l in logistics_data)
        
        # Loss by lane
        loss_by_lane = defaultdict(lambda: {"late_count": 0, "idle_minutes": 0})
        
        for shipment in logistics_data:
            lane = shipment.get("lane", "Unknown")
            if shipment.get("delivery_status") == "delayed":
                loss_by_lane[lane]["late_count"] += 1
            
            idle_time = max(0, shipment.get("dwell_time_minutes", 0) - shipment.get("planned_loading_time", 60))
            loss_by_lane[lane]["idle_minutes"] += idle_time
        
        return {
            "total_late_shipments": len(late_shipments),
            "late_percentage": round(len(late_shipments) / max(len(logistics_data), 1) * 100, 1),
            "total_idle_time": idle_time_total,
            "loss_by_lane": dict(loss_by_lane),
            "cost_impact_inr": idle_time_total * 50,  # 50 INR per idle minute
            "trends": {
                "week_over_week": random.uniform(-10, 10),
                "month_over_month": random.uniform(-15, 15)
            }
        }
    
    def analyze_transport_utilization(self, transport_data: List[Dict]) -> Dict:
        """Analyze transport utilization and costs"""
        
        if not transport_data:
            return {"error": "No transport data available"}
        
        # FTL/LTL analysis
        transport_mix = defaultdict(lambda: {"count": 0, "total_cost": 0, "total_weight": 0})
        
        for transport in transport_data:
            t_type = transport.get("transport_type", "unknown")
            transport_mix[t_type]["count"] += 1
            transport_mix[t_type]["total_cost"] += transport.get("cost_inr", 0)
            transport_mix[t_type]["total_weight"] += transport.get("weight_kg", 0)
        
        # Calculate averages
        for t_type, data in transport_mix.items():
            if data["count"] > 0:
                data["avg_cost_per_kg"] = data["total_cost"] / max(data["total_weight"], 1)
                data["avg_utilization"] = sum(t.get("utilization_percentage", 0) 
                                            for t in transport_data 
                                            if t.get("transport_type") == t_type) / data["count"]
        
        total_cost = sum(data["total_cost"] for data in transport_mix.values())
        
        return {
            "transport_mix": dict(transport_mix),
            "total_cost": total_cost,
            "avg_cost_per_kg": total_cost / max(sum(t.get("weight_kg", 0) for t in transport_data), 1),
            "consolidation_opportunities": len([t for t in transport_data 
                                              if t.get("utilization_percentage", 100) < 80]),
            "carrier_performance": {
                carrier: {"rating": random.uniform(3.5, 5.0), "cost_efficiency": random.uniform(0.7, 1.2)}
                for carrier in set(t.get("carrier", "Unknown") for t in transport_data)
            }
        }
    
    def analyze_warehouse_performance(self, warehouse_data: List[Dict]) -> Dict:
        """Analyze warehouse performance metrics"""
        
        if not warehouse_data:
            return {"error": "No warehouse data available"}
        
        total_bins = len(warehouse_data)
        occupied_bins = len([w for w in warehouse_data if w.get("occupancy_percentage", 0) > 10])
        
        # Zone analysis
        zone_analysis = defaultdict(lambda: {"bins": 0, "avg_occupancy": 0, "pick_frequency": 0})
        
        for bin_data in warehouse_data:
            zone = bin_data.get("zone", "Unknown")
            zone_analysis[zone]["bins"] += 1
            zone_analysis[zone]["avg_occupancy"] += bin_data.get("occupancy_percentage", 0)
            zone_analysis[zone]["pick_frequency"] += bin_data.get("pick_frequency", 0)
        
        # Calculate averages
        for zone_data in zone_analysis.values():
            if zone_data["bins"] > 0:
                zone_data["avg_occupancy"] /= zone_data["bins"]
                zone_data["pick_frequency"] /= zone_data["bins"]
        
        # ABC analysis
        abc_distribution = defaultdict(int)
        for bin_data in warehouse_data:
            abc_distribution[bin_data.get("abc_classification", "C")] += 1
        
        return {
            "total_bins": total_bins,
            "occupancy_rate": round(occupied_bins / max(total_bins, 1) * 100, 1),
            "zone_analysis": dict(zone_analysis),
            "abc_distribution": dict(abc_distribution),
            "putaway_pending": sum(w.get("putaway_pending", 0) for w in warehouse_data),
            "location_accuracy": round(statistics.mean([w.get("location_accuracy", 1.0) 
                                                      for w in warehouse_data]) * 100, 1),
            "optimization_suggestions": [
                "Relocate slow-moving items from Zone A",
                "Increase pick path efficiency in Zone C",
                "Address putaway backlog"
            ]
        }
    
    def optimize_logistics_route(self, route_data: Dict) -> Dict:
        """Optimize delivery route and load planning"""
        
        # Mock optimization algorithm
        locations = route_data.get("locations", [])
        vehicle_capacity = route_data.get("vehicle_capacity", 10000)  # kg
        
        optimized_route = {
            "route_sequence": locations,  # In real implementation, would optimize order
            "estimated_distance": random.randint(100, 500),
            "estimated_time_hours": random.randint(6, 12),
            "fuel_cost_estimate": random.randint(2000, 8000),
            "load_optimization": {
                "utilization_percentage": random.uniform(85, 95),
                "weight_distribution": "balanced",
                "volume_efficiency": random.uniform(80, 90)
            },
            "alternative_routes": [
                {"route": "Route A", "distance": 120, "time": 8, "cost": 3500},
                {"route": "Route B", "distance": 140, "time": 7, "cost": 3200}
            ]
        }
        
        return optimized_route
    
    # ==================== INVENTORY CYCLE COUNT METHODS ====================
    
    def analyze_cycle_count(self, cycle_count_data: List[Dict]) -> Dict:
        """Analyze cycle count variance and adjustments"""
        
        if not cycle_count_data:
            return {"error": "No cycle count data available"}
        
        total_counts = len(cycle_count_data)
        variances = [abs(c.get("variance", 0)) for c in cycle_count_data]
        total_variance = sum(variances)
        
        # Status analysis
        status_count = defaultdict(int)
        for count in cycle_count_data:
            status_count[count.get("status", "unknown")] += 1
        
        # High variance items
        high_variance = [c for c in cycle_count_data 
                        if abs(c.get("variance_percentage", 0)) > 2.0]
        
        return {
            "total_cycle_counts": total_counts,
            "total_variance": total_variance,
            "avg_variance_percentage": round(statistics.mean([abs(c.get("variance_percentage", 0)) 
                                                            for c in cycle_count_data]), 2) if cycle_count_data else 0,
            "status_breakdown": dict(status_count),
            "high_variance_items": high_variance,
            "accuracy_rate": round((total_counts - len(high_variance)) / max(total_counts, 1) * 100, 1),
            "adjustment_queue": [c for c in cycle_count_data if c.get("status") == "pending"],
            "investigation_items": [c for c in cycle_count_data if c.get("status") == "investigating"]
        }
    
    def process_cycle_count_adjustment(self, adjustment_data: Dict) -> Dict:
        """Process cycle count adjustment"""
        
        item_id = adjustment_data.get("item_id")
        adjustment_qty = adjustment_data.get("adjustment_qty", 0)
        reason = adjustment_data.get("reason", "Cycle count adjustment")
        
        return {
            "adjustment_id": f"ADJ_{random.randint(1000, 9999)}",
            "item_id": item_id,
            "adjustment_qty": adjustment_qty,
            "reason": reason,
            "processed_by": "system_user",
            "processing_time": datetime.now().isoformat(),
            "approval_status": "approved" if abs(adjustment_qty) < 100 else "pending_approval",
            "impact_analysis": {
                "cost_impact": abs(adjustment_qty) * 50,  # 50 INR per unit
                "inventory_accuracy_impact": random.uniform(-0.1, 0.2)
            }
        }
    
    # ==================== CORE ANALYTICS METHODS ====================
    
    def calculate_oee(self, production_data: List[Dict]) -> Dict:
        """Calculate OEE metrics from production data"""
        
        if not production_data:
            return self._empty_oee_metrics()
        
        # Aggregate OEE components
        total_availability = sum(d.get("oee_availability", 0) for d in production_data)
        total_performance = sum(d.get("oee_performance", 0) for d in production_data)
        total_quality = sum(d.get("oee_quality", 0) for d in production_data)
        count = len(production_data)
        
        avg_availability = (total_availability / count) * 100 if count > 0 else 0
        avg_performance = (total_performance / count) * 100 if count > 0 else 0
        avg_quality = (total_quality / count) * 100 if count > 0 else 0
        oee = (avg_availability * avg_performance * avg_quality) / 10000
        
        # Calculate 7-day trend
        trend_7day = self._calculate_trend(production_data, "oee", 7)
        
        return {
            "availability": round(avg_availability, 1),
            "performance": round(avg_performance, 1),
            "quality": round(avg_quality, 1),
            "oee": round(oee, 1),
            "target_oee": 85.0,
            "trend_7day": trend_7day,
            "benchmark": 85.0
        }
    
    def calculate_plan_vs_actual(self, production_data: List[Dict]) -> Dict:
        """Calculate plan vs actual metrics"""
        
        if not production_data:
            return self._empty_plan_vs_actual()
        
        total_planned = sum(d.get("planned_qty", 0) for d in production_data)
        total_actual = sum(d.get("actual_qty", 0) for d in production_data)
        total_good = sum(d.get("good_qty", 0) for d in production_data)
        
        adherence = (total_actual / total_planned * 100) if total_planned > 0 else 0
        variance = total_actual - total_planned
        
        # Auto-explain variance
        explanation = self._explain_variance(variance, production_data)
        
        return {
            "date": datetime.now(),
            "planned_quantity": total_planned,
            "actual_quantity": total_actual,
            "good_quantity": total_good,
            "adherence_percentage": round(adherence, 1),
            "variance": variance,
            "variance_reason": self._identify_variance_reason(production_data),
            "auto_explanation": explanation
        }
    
    def calculate_top_losses(self, production_data: List[Dict]) -> List[Dict]:
        """Calculate top losses with Pareto analysis"""
        
        loss_aggregation = defaultdict(lambda: {"duration": 0, "frequency": 0})
        
        # Aggregate losses from production data
        for record in production_data:
            if record.get("downtime_minutes", 0) > 0:
                reason = record.get("downtime_reason", "Unknown")
                loss_aggregation[reason]["duration"] += record["downtime_minutes"]
                loss_aggregation[reason]["frequency"] += 1
        
        # Calculate impact and cumulative percentages
        total_loss = sum(l["duration"] for l in loss_aggregation.values())
        losses = []
        cumulative = 0
        
        for reason, data in sorted(loss_aggregation.items(), 
                                  key=lambda x: x[1]["duration"], reverse=True):
            impact = (data["duration"] / total_loss * 100) if total_loss > 0 else 0
            cumulative += impact
            
            losses.append({
                "reason": reason,
                "duration_minutes": data["duration"],
                "frequency": data["frequency"],
                "impact_percentage": round(impact, 1),
                "cumulative_percentage": round(cumulative, 1),
                "owner": self._assign_owner(reason),
                "root_cause": self._identify_root_cause(reason)
            })
        
        return losses[:10]  # Top 10 losses
    
    def calculate_scrap_by_machine(self, production_data: List[Dict]) -> List[Dict]:
        """Calculate scrap analysis by machine"""
        
        machine_metrics = defaultdict(lambda: {
            "total_produced": 0, "scrap": 0, "good": 0, "defects": defaultdict(int)
        })
        
        for record in production_data:
            machine = record.get("machine_id")
            if machine:
                machine_metrics[machine]["total_produced"] += record.get("actual_qty", 0)
                machine_metrics[machine]["scrap"] += record.get("scrap_qty", 0)
                machine_metrics[machine]["good"] += record.get("good_qty", 0)
        
        results = []
        for machine, metrics in machine_metrics.items():
            scrap_pct = (metrics["scrap"] / metrics["total_produced"] * 100) \
                       if metrics["total_produced"] > 0 else 0
            fpy = (metrics["good"] / metrics["total_produced"] * 100) \
                  if metrics["total_produced"] > 0 else 0
            
            results.append({
                "machine_id": machine,
                "scrap_percentage": round(scrap_pct, 2),
                "scrap_cost_inr": metrics["scrap"] * 150,  # Assuming 150 INR/unit
                "fpy": round(fpy, 1),
                "defect_types": dict(metrics["defects"]),
                "trend_data": self._generate_trend_data()
            })
        
        return results
    
    # Helper methods
    def _empty_oee_metrics(self) -> Dict:
        return {
            "availability": 0, "performance": 0, "quality": 0, "oee": 0,
            "target_oee": 85.0, "trend_7day": [], "benchmark": 85.0
        }
    
    def _empty_plan_vs_actual(self) -> Dict:
        return {
            "date": datetime.now(),
            "planned_quantity": 0,
            "actual_quantity": 0,
            "good_quantity": 0,
            "adherence_percentage": 0,
            "variance": 0
        }
    
    def _calculate_trend(self, data: List[Dict], metric: str, days: int) -> List[float]:
        """Calculate trend for a metric"""
        trend = []
        for i in range(min(days, len(data))):
            value = data[i].get(metric, 0)
            if metric == "oee":
                value *= 100
            trend.append(round(value, 1))
        return trend
    
    def _explain_variance(self, variance: int, data: List[Dict]) -> str:
        """Auto-explain production variance"""
        if variance > 0:
            return f"Production exceeded plan by {abs(variance)} units due to improved efficiency"
        elif variance < 0:
            return f"Production short by {abs(variance)} units due to various factors"
        return "Production met plan exactly"
    
    def _identify_variance_reason(self, data: List[Dict]) -> str:
        """Identify primary variance reason"""
        if any(d.get("catastrophic_failure") for d in data):
            return "Equipment failure"
        return "Normal variation"
    
    def _assign_owner(self, reason: str) -> str:
        """Assign owner based on loss reason"""
        ownership_map = {
            "Material": "Supply Chain",
            "Breakdown": "Maintenance",
            "Quality": "Quality Team",
            "Changeover": "Production",
            "Power": "Facilities"
        }
        
        for key, owner in ownership_map.items():
            if key.lower() in reason.lower():
                return owner
        return "Production Manager"
    
    def _identify_root_cause(self, reason: str) -> str:
        """Identify root cause for loss reason"""
        root_cause_map = {
            "Material": "Supplier delay or inventory planning gap",
            "Breakdown": "Preventive maintenance gap or component wear",
            "Quality": "Process variation or operator training"
        }
        
        for key, cause in root_cause_map.items():
            if key.lower() in reason.lower():
                return cause
        return "Under investigation"
    
    def _generate_trend_data(self) -> List[float]:
        """Generate sample trend data"""
        return [random.uniform(1, 5) for _ in range(7)]
    
    def calculate_fpy(self, quality_data: List[Dict], item: Optional[str] = None, 
                     tool: Optional[str] = None) -> Dict:
        """Calculate First Pass Yield"""
        
        if not quality_data:
            return {
                "item": item,
                "tool": tool,
                "fpy_percentage": 0, 
                "trend_data": [], 
                "spc_upper_limit": 100, 
                "spc_lower_limit": 90, 
                "defect_breakdown": {}
            }
        
        total_inspected = sum(q.get("total_inspected", 0) for q in quality_data)
        total_defects = sum(q.get("defects_found", 0) for q in quality_data)
        
        fpy = ((total_inspected - total_defects) / total_inspected * 100) \
              if total_inspected > 0 else 0
        
        # Aggregate defect types
        defect_breakdown = defaultdict(int)
        for record in quality_data:
            for defect_type, count in record.get("defect_types", {}).items():
                defect_breakdown[defect_type] += count
        
        # Calculate SPC limits
        fpy_values = [(q.get("fpy", 0) * 100) for q in quality_data]
        mean_fpy = statistics.mean(fpy_values) if fpy_values else 95
        std_fpy = statistics.stdev(fpy_values) if len(fpy_values) > 1 else 2
        
        return {
            "item": item,
            "tool": tool,
            "fpy_percentage": round(fpy, 1),
            "trend_data": fpy_values[-7:] if len(fpy_values) >= 7 else fpy_values,
            "spc_upper_limit": round(min(100, mean_fpy + 3 * std_fpy), 1),
            "spc_lower_limit": round(max(0, mean_fpy - 3 * std_fpy), 1),
            "defect_breakdown": dict(defect_breakdown)
        }
    
    def analyze_defects_by_tool(self, quality_data: List[Dict]) -> Dict:
        """Analyze defects by tool/mold"""
        tool_defects = defaultdict(lambda: {"count": 0, "rate": 0.0, "types": defaultdict(int)})
        
        for record in quality_data:
            tool_id = record.get("tool_id", "unknown")
            defects = record.get("defects_found", 0)
            inspected = record.get("units_inspected", 0)
            
            tool_defects[tool_id]["count"] += defects
            tool_defects[tool_id]["inspected"] = tool_defects[tool_id].get("inspected", 0) + inspected
            
            # Process defect types
            for defect_type in record.get("defect_types", []):
                tool_defects[tool_id]["types"][defect_type] += 1
        
        # Calculate defect rates
        result = {}
        for tool_id, data in tool_defects.items():
            inspected = data.get("inspected", 0)
            if inspected > 0:
                defect_rate = (data["count"] / inspected) * 100
            else:
                defect_rate = 0.0
                
            result[tool_id] = {
                "defect_count": data["count"],
                "defect_rate": round(defect_rate, 2),
                "units_inspected": inspected,
                "defect_types": dict(data["types"])
            }
        
        return {
            "by_tool": result,
            "total_defects": sum(data["count"] for data in tool_defects.values()),
            "total_inspected": sum(data.get("inspected", 0) for data in tool_defects.values()),
            "overall_rate": round((sum(data["count"] for data in tool_defects.values()) / 
                                 max(sum(data.get("inspected", 0) for data in tool_defects.values()), 1)) * 100, 2)
        }
