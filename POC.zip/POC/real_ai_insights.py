"""
Real AI Insights Engine for Logic Leap
Integrates with Google Gemini AI for actual intelligent analysis
Implements real statistical calculations and machine learning predictions
"""

import os
import json
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
import statistics
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import google.generativeai as genai
from dotenv import load_dotenv
import warnings
warnings.filterwarnings('ignore')

# Load environment variables
load_dotenv()

class RealAIInsightsEngine:
    def __init__(self):
        # Initialize Gemini AI
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        if not self.gemini_api_key:
            raise ValueError("GEMINI_API_KEY not found in environment variables")
        
        genai.configure(api_key=self.gemini_api_key)
        self.gemini_model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Initialize ML models
        self.prediction_models = {}
        self.scalers = {}
        self.anomaly_detectors = {}
        
        # Performance thresholds
        self.thresholds = {
            "oee": {"excellent": 85, "good": 75, "poor": 60},
            "quality": {"excellent": 99, "good": 95, "poor": 90},
            "availability": {"excellent": 90, "good": 80, "poor": 70},
            "performance": {"excellent": 95, "good": 85, "poor": 75}
        }
    
    def prepare_time_series_features(self, data: List[Dict], target_metric: str) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare time series features for ML models"""
        
        # Sort data by timestamp
        sorted_data = sorted(data, key=lambda x: x.get('timestamp', x.get('date', '')))
        
        features = []
        targets = []
        
        for i, record in enumerate(sorted_data):
            if target_metric in record:
                # Time-based features
                timestamp = datetime.fromisoformat(record.get('timestamp', record.get('date')))
                
                feature_vector = [
                    timestamp.hour,  # Hour of day
                    timestamp.weekday(),  # Day of week
                    timestamp.day,  # Day of month
                    i,  # Sequential index
                ]
                
                # Operational features
                if 'oee_availability' in record:
                    feature_vector.extend([
                        record.get('oee_availability', 0),
                        record.get('oee_performance', 0),
                        record.get('oee_quality', 0)
                    ])
                
                # Environmental features
                if 'temperature_celsius' in record:
                    feature_vector.extend([
                        record.get('temperature_celsius', 25),
                        record.get('humidity_percent', 50)
                    ])
                
                # Machine features
                machine_id = record.get('machine_id', 'Machine_1')
                machine_num = int(machine_id.split('_')[-1]) if '_' in machine_id else 1
                feature_vector.append(machine_num)
                
                # Operator features
                operator_efficiency = record.get('operator_efficiency', 0.9)
                feature_vector.append(operator_efficiency)
                
                # Shift encoding
                shift = record.get('shift', 'morning')
                shift_encoded = {'morning': 1, 'afternoon': 2, 'night': 3}.get(shift, 1)
                feature_vector.append(shift_encoded)
                
                features.append(feature_vector)
                targets.append(record[target_metric])
        
        return np.array(features), np.array(targets)
    
    def train_prediction_model(self, data: List[Dict], target_metric: str) -> Dict:
        """Train ML model for predictions"""
        
        if len(data) < 10:  # Need minimum data points
            return {"status": "insufficient_data", "message": "Not enough data to train model"}
        
        try:
            X, y = self.prepare_time_series_features(data, target_metric)
            
            if len(X) == 0:
                return {"status": "no_features", "message": "Could not extract features from data"}
            
            # Split data (80% train, 20% test)
            split_idx = int(len(X) * 0.8)
            X_train, X_test = X[:split_idx], X[split_idx:]
            y_train, y_test = y[:split_idx], y[split_idx:]
            
            # Scale features
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            # Train Random Forest model (better for manufacturing data)
            model = RandomForestRegressor(n_estimators=100, random_state=42, max_depth=10)
            model.fit(X_train_scaled, y_train)
            
            # Calculate accuracy
            train_score = model.score(X_train_scaled, y_train)
            test_score = model.score(X_test_scaled, y_test) if len(X_test) > 0 else train_score
            
            # Store model and scaler
            self.prediction_models[target_metric] = model
            self.scalers[target_metric] = scaler
            
            # Train anomaly detector
            anomaly_detector = IsolationForest(contamination=0.1, random_state=42)
            anomaly_detector.fit(X_train_scaled)
            self.anomaly_detectors[target_metric] = anomaly_detector
            
            return {
                "status": "success",
                "model_type": "RandomForestRegressor",
                "train_score": round(train_score, 3),
                "test_score": round(test_score, 3),
                "feature_count": X.shape[1],
                "data_points": len(X),
                "feature_importance": model.feature_importances_.tolist()
            }
        
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    async def generate_predictions_with_gemini_first(self, historical_data: List[Dict], target: str, 
                                                   horizon_hours: int) -> Dict:
        """Generate predictions using Gemini AI first, fallback to ML models"""
        
        # Try Gemini AI first
        try:
            genai.configure(api_key=self.gemini_api_key)
            self.gemini_model = genai.GenerativeModel('gemini-1.5-flash')
            
            # Prepare data summary for Gemini
            data_summary = self._prepare_prediction_data_summary(historical_data, target)
            
            prompt = f"""
            As a manufacturing analytics expert, analyze this historical {target} data and provide predictions:
            
            Historical Data Summary:
            {data_summary}
            
            Target Metric: {target}
            Prediction Horizon: {horizon_hours} hours
            
            Please provide:
            1. Predicted values for each hour (1-{horizon_hours})
            2. Confidence level (0.0-1.0)
            3. Key factors influencing the prediction
            4. Risk assessment
            
            Respond in JSON format:
            {{
                "predictions": [hour1_value, hour2_value, ...],
                "average_prediction": predicted_average,
                "confidence": 0.85,
                "confidence_interval": {{"lower": lower_bound, "upper": upper_bound}},
                "key_factors": ["factor1", "factor2"],
                "risks": ["risk1", "risk2"],
                "trend_analysis": "increasing/decreasing/stable",
                "method": "gemini_ai"
            }}
            """
            
            response = self.gemini_model.generate_content(prompt)
            
            try:
                ai_response = json.loads(response.text.strip())
                
                # Add metadata
                ai_response["target"] = target
                ai_response["timestamp"] = datetime.now().isoformat()
                ai_response["horizon_hours"] = horizon_hours
                ai_response["data_points_analyzed"] = len(historical_data)
                ai_response["predicted_value"] = ai_response.get("average_prediction", 0)
                ai_response["predicted_values"] = ai_response.get("predictions", [])
                
                return ai_response
                
            except json.JSONDecodeError:
                print(f"Gemini response parsing failed for {target} prediction")
                # Fall back to ML models
                return self.generate_predictions_with_ml(historical_data, target, horizon_hours)
                
        except Exception as e:
            print(f"Gemini prediction failed for {target}: {str(e)}")
            # Fall back to ML models
            return self.generate_predictions_with_ml(historical_data, target, horizon_hours)
    
    def generate_predictions_with_ml(self, historical_data: List[Dict], target: str, 
                                   horizon_hours: int) -> Dict:
        """Generate predictions using trained ML models (fallback method)"""
        
        # Train model if not exists
        if target not in self.prediction_models:
            training_result = self.train_prediction_model(historical_data, target)
            if training_result["status"] != "success":
                return self._fallback_prediction(target, horizon_hours, training_result["message"])
        
        try:
            model = self.prediction_models[target]
            scaler = self.scalers[target]
            
            # Get latest data point for prediction
            if not historical_data:
                return self._fallback_prediction(target, horizon_hours, "No historical data")
            
            latest_record = historical_data[-1]
            current_time = datetime.now()
            
            predictions = []
            confidence_values = []
            
            for hour in range(1, horizon_hours + 1):
                future_time = current_time + timedelta(hours=hour)
                
                # Create feature vector for future time
                feature_vector = [
                    future_time.hour,
                    future_time.weekday(),
                    future_time.day,
                    len(historical_data) + hour,  # Sequential index
                    latest_record.get('oee_availability', 0.85),
                    latest_record.get('oee_performance', 0.90),
                    latest_record.get('oee_quality', 0.95),
                    latest_record.get('temperature_celsius', 25),
                    latest_record.get('humidity_percent', 50),
                    1,  # Machine number (simplified)
                    latest_record.get('operator_efficiency', 0.9),
                    {'morning': 1, 'afternoon': 2, 'night': 3}.get(
                        'morning' if 6 <= future_time.hour < 14 else 
                        'afternoon' if 14 <= future_time.hour < 22 else 'night', 1
                    )
                ]
                
                # Scale and predict
                feature_scaled = scaler.transform([feature_vector])
                prediction = model.predict(feature_scaled)[0]
                
                # Calculate confidence using ensemble variance
                if hasattr(model, 'estimators_'):
                    individual_predictions = [tree.predict(feature_scaled)[0] for tree in model.estimators_]
                    confidence = max(0.5, 1 - (np.std(individual_predictions) / np.mean(individual_predictions)))
                else:
                    confidence = 0.8
                
                # Apply realistic bounds
                prediction = self._apply_bounds(prediction, target)
                
                predictions.append(prediction)
                confidence_values.append(confidence)
            
            # Overall confidence
            avg_confidence = np.mean(confidence_values)
            
            # Calculate confidence interval
            prediction_std = np.std(predictions) if len(predictions) > 1 else np.mean(predictions) * 0.05
            
            return {
                "target": target,
                "timestamp": current_time,
                "horizon_hours": horizon_hours,
                "predicted_values": [round(p, 2) for p in predictions],
                "predicted_value": round(predictions[-1], 2),  # Last prediction
                "confidence_interval": {
                    "lower": round(predictions[-1] - 1.96 * prediction_std, 2),
                    "upper": round(predictions[-1] + 1.96 * prediction_std, 2),
                    "confidence": round(avg_confidence, 2)
                },
                "model_info": {
                    "type": "RandomForestRegressor",
                    "trained_on_points": len(historical_data),
                    "prediction_method": "ml_ensemble"
                },
                "contributing_factors": self._identify_ml_factors(target, model, scaler)
            }
        
        except Exception as e:
            return self._fallback_prediction(target, horizon_hours, f"ML prediction failed: {str(e)}")
    
    def _apply_bounds(self, value: float, target: str) -> float:
        """Apply realistic bounds to predictions"""
        bounds = {
            "oee": (0, 100),
            "quality": (80, 100),
            "availability": (50, 100),
            "performance": (60, 120),
            "downtime": (0, 500)
        }
        
        min_val, max_val = bounds.get(target, (0, 1000))
        return max(min_val, min(max_val, value))
    
    def _fallback_prediction(self, target: str, horizon_hours: int, reason: str) -> Dict:
        """Fallback prediction when ML fails"""
        base_values = {"oee": 75, "quality": 95, "availability": 85, "performance": 90, "downtime": 45}
        base_value = base_values.get(target, 50)
        
        return {
            "target": target,
            "timestamp": datetime.now(),
            "horizon_hours": horizon_hours,
            "predicted_value": base_value,
            "confidence_interval": {"lower": base_value * 0.9, "upper": base_value * 1.1, "confidence": 0.5},
            "model_info": {"type": "fallback", "reason": reason},
            "contributing_factors": []
        }
    
    def _identify_ml_factors(self, target: str, model, scaler) -> List[Dict]:
        """Identify contributing factors using feature importance"""
        
        feature_names = [
            "hour_of_day", "day_of_week", "day_of_month", "sequence",
            "availability", "performance", "quality", "temperature", 
            "humidity", "machine_id", "operator_efficiency", "shift"
        ]
        
        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
            
            # Get top 3 most important features
            top_indices = np.argsort(importances)[-3:][::-1]
            
            factors = []
            for idx in top_indices:
                if idx < len(feature_names):
                    factors.append({
                        "factor": feature_names[idx],
                        "importance": round(float(importances[idx]), 3),
                        "impact_type": "positive" if importances[idx] > 0.1 else "moderate"
                    })
            
            return factors
        
        return [{"factor": "model_ensemble", "importance": 0.8, "impact_type": "positive"}]
    
    async def generate_ai_insights_with_gemini(self, data_context: Dict) -> Dict:
        """Generate insights using Gemini AI"""
        
        try:
            # Prepare data summary for Gemini
            data_summary = self._prepare_data_summary(data_context)
            
            prompt = f"""
            As a manufacturing analytics expert, analyze this production data and provide actionable insights:
            
            {data_summary}
            
            Please provide:
            1. Key performance insights (2-3 bullet points)
            2. Specific recommendations with expected impact
            3. Risk assessment
            4. Priority level (1-5, where 1 is most urgent)
            
            Respond in JSON format:
            {{
                "insights": ["insight1", "insight2"],
                "recommendations": ["rec1", "rec2"],
                "risks": [{"risk": "sample_risk", "probability": "high", "impact": "medium"}],
                "priority": 1,
                "confidence": 0.85,
                "summary": "One sentence summary"
            }}
            """
            
            response = self.gemini_model.generate_content(prompt)
            
            # Parse response
            try:
                ai_response = json.loads(response.text.strip())
                
                # Add metadata
                ai_response["ai_model"] = "Gemini-1.5-Flash"
                ai_response["generated_at"] = datetime.now().isoformat()
                ai_response["data_points_analyzed"] = data_context.get("data_points", 0)
                
                return ai_response
                
            except json.JSONDecodeError:
                # Fallback if JSON parsing fails
                return {
                    "insights": [response.text[:200] + "..." if len(response.text) > 200 else response.text],
                    "recommendations": ["Review the detailed AI analysis"],
                    "risks": [{"risk": "Data analysis incomplete", "probability": "low", "impact": "medium"}],
                    "priority": 3,
                    "confidence": 0.7,
                    "summary": "AI analysis completed with partial results",
                    "ai_model": "Gemini-1.5-Flash",
                    "generated_at": datetime.now().isoformat(),
                    "raw_response": response.text
                }
        
        except Exception as e:
            # Fallback insights
            return {
                "insights": ["Unable to connect to AI service", "Using fallback analysis"],
                "recommendations": ["Check AI service connectivity", "Review data quality"],
                "risks": [{"risk": "AI service unavailable", "probability": "current", "impact": "low"}],
                "priority": 4,
                "confidence": 0.5,
                "summary": "Fallback analysis due to AI service issues",
                "ai_model": "Fallback",
                "error": str(e),
                "generated_at": datetime.now().isoformat()
            }
    
    def _prepare_data_summary(self, data_context: Dict) -> str:
        """Prepare data summary for AI analysis"""
        
        summary_parts = []
        
        # Production metrics
        if "oee_metrics" in data_context:
            oee = data_context["oee_metrics"]
            summary_parts.append(f"OEE: {oee.get('oee', 0):.1f}% (A: {oee.get('availability', 0):.1f}%, P: {oee.get('performance', 0):.1f}%, Q: {oee.get('quality', 0):.1f}%)")
        
        # Production variance
        if "plan_vs_actual" in data_context:
            pva = data_context["plan_vs_actual"]
            summary_parts.append(f"Production: Planned {pva.get('planned_quantity', 0)} vs Actual {pva.get('actual_quantity', 0)} (Variance: {pva.get('variance', 0)})")
        
        # Quality data
        if "quality_data" in data_context:
            quality = data_context["quality_data"]
            if quality:
                avg_fpy = np.mean([q.get('fpy', 0) * 100 for q in quality])
                summary_parts.append(f"Quality: Average FPY {avg_fpy:.1f}%")
        
        # Downtime
        if "downtime_data" in data_context:
            downtime = data_context["downtime_data"]
            if downtime:
                total_downtime = sum(d.get('duration_minutes', 0) for d in downtime)
                summary_parts.append(f"Downtime: {total_downtime:.0f} minutes total")
        
        # Scenario flags
        if "scenario_flags" in data_context:
            flags = data_context["scenario_flags"]
            if flags:
                summary_parts.append(f"Active scenarios: {', '.join(flags)}")
        
        # Time context
        summary_parts.append(f"Analysis period: {data_context.get('time_period', 'Last 24 hours')}")
        
        return "; ".join(summary_parts)
    
    async def generate_ceo_brief_with_ai(self, all_data: Dict) -> Dict:
        """Generate CEO brief using AI analysis"""
        
        try:
            # Prepare comprehensive data summary
            data_summary = self._prepare_comprehensive_summary(all_data)
            
            prompt = f"""
            As a senior manufacturing consultant, create a 60-second executive brief for a CEO based on this data:
            
            {data_summary}
            
            Format as JSON:
            {{
                "executive_summary": "2-3 sentence summary focusing on business impact",
                "key_metrics": {{"oee": 75.2, "quality": 96.1, "delivery": 92.3}},
                "critical_issues": ["issue1", "issue2"],
                "recommended_actions": [
                    {{"action": "description", "owner": "role", "timeline": "timeframe", "expected_impact": "benefit"}}
                ],
                "financial_impact": {{"cost_savings_potential": 150000, "risk_exposure": 75000}},
                "outlook": "positive/neutral/concerning"
            }}
            """
            
            response = self.gemini_model.generate_content(prompt)
            
            try:
                ceo_brief = json.loads(response.text.strip())
                
                # Add metadata
                ceo_brief["generated_at"] = datetime.now().isoformat()
                ceo_brief["ai_generated"] = True
                ceo_brief["data_freshness"] = "Real-time"
                
                return ceo_brief
                
            except json.JSONDecodeError:
                return self._fallback_ceo_brief(all_data, response.text)
        
        except Exception as e:
            return self._fallback_ceo_brief(all_data, str(e))
    
    def _prepare_comprehensive_summary(self, all_data: Dict) -> str:
        """Prepare comprehensive summary for CEO brief"""
        
        summary = []
        
        production_data = all_data.get("production", [])
        quality_data = all_data.get("quality", [])
        downtime_data = all_data.get("downtime", [])
        
        if production_data:
            avg_oee = np.mean([p.get('oee', 0) * 100 for p in production_data])
            total_produced = sum(p.get('actual_qty', 0) for p in production_data)
            total_planned = sum(p.get('planned_qty', 0) for p in production_data)
            
            summary.append(f"Production: {total_produced} units produced vs {total_planned} planned (OEE: {avg_oee:.1f}%)")
        
        if quality_data:
            avg_defect_rate = np.mean([q.get('defect_rate', 0) for q in quality_data])
            summary.append(f"Quality: {avg_defect_rate:.2f}% defect rate")
        
        if downtime_data:
            total_downtime = sum(d.get('duration_minutes', 0) for d in downtime_data)
            downtime_hours = total_downtime / 60
            summary.append(f"Downtime: {downtime_hours:.1f} hours total")
        
        return "; ".join(summary)
    
    def _fallback_ceo_brief(self, all_data: Dict, error_info: str) -> Dict:
        """Fallback CEO brief when AI fails"""
        
        return {
            "executive_summary": "Manufacturing operations continuing with mixed performance indicators requiring management attention.",
            "key_metrics": {"oee": 75.0, "quality": 95.0, "delivery": 90.0},
            "critical_issues": ["AI analysis temporarily unavailable", "Manual review recommended"],
            "recommended_actions": [
                {"action": "Review production metrics manually", "owner": "Production Manager", "timeline": "Today", "expected_impact": "Maintain oversight"}
            ],
            "financial_impact": {"cost_savings_potential": 100000, "risk_exposure": 50000},
            "outlook": "neutral",
            "generated_at": datetime.now().isoformat(),
            "ai_generated": False,
            "fallback_reason": error_info,
            "data_freshness": "Real-time"
        }
    
    def detect_anomalies(self, data: List[Dict], target_metric: str) -> List[Dict]:
        """Detect anomalies using ML models"""
        
        if target_metric not in self.anomaly_detectors:
            # Train anomaly detector if not exists
            self.train_prediction_model(data, target_metric)
        
        if target_metric not in self.anomaly_detectors:
            return []
        
        try:
            detector = self.anomaly_detectors[target_metric]
            scaler = self.scalers[target_metric]
            
            X, y = self.prepare_time_series_features(data, target_metric)
            
            if len(X) == 0:
                return []
            
            X_scaled = scaler.transform(X)
            anomaly_scores = detector.decision_function(X_scaled)
            anomalies = detector.predict(X_scaled)
            
            anomaly_records = []
            
            for i, (is_anomaly, score) in enumerate(zip(anomalies, anomaly_scores)):
                if is_anomaly == -1:  # Anomaly detected
                    record = data[i]
                    anomaly_records.append({
                        "timestamp": record.get('timestamp', record.get('date')),
                        "metric": target_metric,
                        "value": record.get(target_metric),
                        "anomaly_score": float(score),
                        "severity": "high" if score < -0.5 else "medium",
                        "machine_id": record.get('machine_id'),
                        "shift": record.get('shift'),
                        "potential_causes": self._identify_anomaly_causes(record)
                    })
            
            return anomaly_records
        
        except Exception as e:
            print(f"Anomaly detection failed: {e}")
            return []
    
    def _identify_anomaly_causes(self, record: Dict) -> List[str]:
        """Identify potential causes of anomalies"""
        
        causes = []
        
        # Check scenario flags
        scenario_flags = record.get('scenario_flags', [])
        if 'tool_wear' in scenario_flags:
            causes.append("Tool wear detected")
        if 'monsoon_moisture' in scenario_flags:
            causes.append("Material moisture issues")
        if 'power_issues' in scenario_flags:
            causes.append("Power quality problems")
        if 'catastrophic_failure' in scenario_flags:
            causes.append("Equipment failure")
        
        # Check operational conditions
        if record.get('operator_efficiency', 1) < 0.8:
            causes.append("Operator performance below standard")
        
        if record.get('temperature_celsius', 25) > 35:
            causes.append("High ambient temperature")
        
        if record.get('humidity_percent', 50) > 80:
            causes.append("High humidity levels")
        
        return causes if causes else ["Unknown cause - requires investigation"]
    
    def calculate_real_statistics(self, data: List[Dict]) -> Dict:
        """Calculate comprehensive real statistics"""
        
        if not data:
            return {"error": "No data provided"}
        
        stats = {}
        
        # OEE Statistics
        oee_values = [d.get('oee', 0) * 100 for d in data if 'oee' in d]
        if oee_values:
            stats['oee'] = {
                "mean": round(np.mean(oee_values), 2),
                "median": round(np.median(oee_values), 2),
                "std": round(np.std(oee_values), 2),
                "min": round(min(oee_values), 2),
                "max": round(max(oee_values), 2),
                "percentile_95": round(np.percentile(oee_values, 95), 2),
                "trend": self._calculate_trend(oee_values),
                "control_limits": self._calculate_control_limits(oee_values)
            }
        
        # Quality Statistics
        fpy_values = [d.get('fpy', 0) for d in data if 'fpy' in d]
        if fpy_values:
            stats['quality'] = {
                "mean_fpy": round(np.mean(fpy_values), 3),
                "defect_rate": round(np.mean([d.get('defect_rate', 0) for d in data]), 4),
                "capability_index": self._calculate_cpk(fpy_values, 0.95, 1.0),
                "control_limits": self._calculate_control_limits(fpy_values)
            }
        
        # Production Statistics
        actual_qty = [d.get('actual_qty', 0) for d in data if 'actual_qty' in d]
        if actual_qty:
            stats['production'] = {
                "total_produced": sum(actual_qty),
                "average_per_shift": round(np.mean(actual_qty), 0),
                "production_variance": round(np.var(actual_qty), 2),
                "throughput_stability": round(1 - (np.std(actual_qty) / np.mean(actual_qty)), 3)
            }
        
        return stats
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction"""
        if len(values) < 2:
            return "insufficient_data"
        
        # Simple linear regression for trend
        x = np.arange(len(values))
        slope = np.polyfit(x, values, 1)[0]
        
        if slope > 0.1:
            return "increasing"
        elif slope < -0.1:
            return "decreasing"
        else:
            return "stable"
    
    def _calculate_control_limits(self, values: List[float]) -> Dict:
        """Calculate statistical control limits"""
        if len(values) < 3:
            return {"ucl": 0, "lcl": 0, "center": 0}
        
        mean_val = np.mean(values)
        std_val = np.std(values)
        
        return {
            "ucl": round(mean_val + 3 * std_val, 3),  # Upper Control Limit
            "lcl": round(max(0, mean_val - 3 * std_val), 3),  # Lower Control Limit
            "center": round(mean_val, 3)
        }
    
    def _calculate_cpk(self, values: List[float], lsl: float, usl: float) -> float:
        """Calculate Process Capability Index (Cpk)"""
        if len(values) < 10:
            return 0.0
        
        mean_val = np.mean(values)
        std_val = np.std(values)
        
        if std_val == 0:
            return float('inf')
        
        cpu = (usl - mean_val) / (3 * std_val)
        cpl = (mean_val - lsl) / (3 * std_val)
        
        return round(min(cpu, cpl), 3)
    
    def _prepare_prediction_data_summary(self, historical_data: List[Dict], target: str) -> str:
        """Prepare data summary for Gemini analysis"""
        
        if not historical_data:
            return "No historical data available"
        
        # Get relevant metrics based on target
        target_metrics = {
            "oee": ["oee_percentage", "oee_availability", "oee_performance", "oee_quality"],
            "quality": ["first_pass_yield", "defects_found", "units_inspected"],
            "availability": ["oee_availability", "downtime_minutes"],
            "performance": ["oee_performance", "actual_output", "planned_output"],
            "downtime": ["downtime_minutes", "unplanned_downtime"]
        }
        
        relevant_fields = target_metrics.get(target, ["oee_percentage"])
        
        # Statistical summary
        summary_stats = {}
        for field in relevant_fields:
            values = [record.get(field, 0) for record in historical_data if field in record]
            if values:
                summary_stats[field] = {
                    "current": values[-1],
                    "average": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "trend": "increasing" if values[-1] > values[0] else "decreasing" if values[-1] < values[0] else "stable"
                }
        
        # Recent data points (last 5)
        recent_data = historical_data[-5:]
        
        # Scenario analysis
        scenarios = []
        for record in historical_data[-10:]:  # Check last 10 records
            scenario_flags = record.get("scenario_flags", [])
            if scenario_flags:
                scenarios.extend(scenario_flags)
        
        unique_scenarios = list(set(scenarios))
        
        # Prepare filtered recent data
        filtered_recent_data = []
        for record in recent_data:
            filtered_record = {k: v for k, v in record.items() if k in relevant_fields + ['timestamp', 'shift', 'machine_id']}
            filtered_recent_data.append(filtered_record)
        
        summary = f"""
        Data Points: {len(historical_data)}
        Time Period: {recent_data[0].get('timestamp', 'N/A')} to {recent_data[-1].get('timestamp', 'N/A')}
        
        Statistical Summary:
        {json.dumps(summary_stats, indent=2)}
        
        Recent Observations (last 5 records):
        {json.dumps(filtered_recent_data, indent=2)}
        
        Active Scenarios: {unique_scenarios}
        
        Key Patterns:
        - Shift Performance: Morning vs Afternoon vs Night variations
        - Machine Variations: Different machine performance characteristics
        - Environmental Factors: Temperature, humidity impacts
        - Operational Scenarios: Tool wear, maintenance, quality issues
        """
        
        return summary