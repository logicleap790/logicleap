# Logic Leap Manufacturing Analytics API

A comprehensive FastAPI-based manufacturing analytics platform with real-time data processing, AI-powered insights, and predictive analytics for industrial operations.

## 🌟 Features

- **Real-time Manufacturing Analytics**: OEE, FPY, MTTR/MTBF calculations
- **AI-Powered Insights**: Google Gemini integration with ML fallback
- **Predictive Analytics**: Machine learning models for production forecasting  
- **Comprehensive Coverage**: 36+ endpoints covering all manufacturing domains
- **Real Data Generation**: Realistic manufacturing scenarios with seasonal patterns
- **Production-Ready**: Built with FastAPI, includes CORS, error handling

## 🚀 Quick Start

### Prerequisites

```bash
pip install fastapi uvicorn google-generativeai scikit-learn pandas numpy python-dotenv
```

### Environment Setup

Create a `.env` file:

```env
GEMINI_API_KEY=your_gemini_api_key_here
HOST=0.0.0.0
PORT=8000
```

### Running the API

```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

API will be available at: `http://localhost:8000`
Interactive docs at: `http://localhost:8000/docs`

## 📊 API Endpoints Overview

### Executive Overview
- `GET /api/overview/executive` - Complete executive dashboard
- `GET /api/overview/kpi-tiles` - KPI summary tiles

### Production Analytics
- `GET /api/production/shift-output` - Shift performance metrics
- `GET /api/production/downtime` - Downtime analysis by reason
- `GET /api/production/changeovers` - Changeover performance
- `GET /api/production/fpy` - First Pass Yield analysis

### Quality Management  
- `GET /api/quality/defects-by-tool` - Defect analysis by tool/mold
- `GET /api/quality/scrap-cost` - Scrap cost analysis
- `GET /api/quality/capa` - CAPA status tracking

### AI & Predictions
- `GET /api/ai/insights` - AI-generated insights (Gemini-first)
- `GET /api/ai/predictions` - ML predictions with confidence intervals
- `GET /api/ai/ceo-brief` - Executive summary with AI analysis

### Inventory Management
- `GET /api/inventory/alerts` - Min/max inventory alerts
- `GET /api/inventory/material-availability` - Material shortage analysis
- `GET /api/inventory/wip-aging` - Work-in-progress aging
- `GET /api/inventory/cycle-count` - Cycle count variance

### Assembly & Logistics
- `GET /api/assembly/fg-mismatch` - FG to Assembly reconciliation
- `GET /api/logistics/dispatch-receipt` - Shipment tracking
- `GET /api/logistics/transport-utilization` - Fleet optimization

## 📋 API Response Examples

### Executive Overview

```json
{
  "oee_snapshot": {
    "availability": 85.4,
    "performance": 94.8,
    "quality": 93.7,
    "oee": 75.9,
    "target_oee": 85.0,
    "trend_7day": [85.0, 78.0, 68.4, 71.8, 79.7, 70.8, 72.6]
  },
  "plan_vs_actual": {
    "planned_quantity": 30353,
    "actual_quantity": 28971,
    "variance": -1382,
    "adherence_percentage": 95.4
  },
  "ai_insights": [
    {
      "type": "performance_gap",
      "confidence": 0.95,
      "message": "OEE is 9.1% below target. Focus on availability",
      "recommendation": "Implement targeted improvement actions",
      "priority": 1
    }
  ],
  "timestamp": "2025-08-30T13:28:36.123456"
}
```

### AI Predictions

```json
{
  "target": "oee",
  "timestamp": "2025-08-30T13:01:06.477094",
  "horizon_hours": 4,
  "predicted_values": [0.86, 0.86, 0.86, 0.86],
  "predicted_value": 0.86,
  "confidence_interval": {
    "lower": 0.86,
    "upper": 0.86,
    "confidence": 0.98
  },
  "model_info": {
    "type": "RandomForestRegressor", 
    "trained_on_points": 720,
    "prediction_method": "ml_ensemble"
  },
  "contributing_factors": [
    {
      "factor": "performance",
      "importance": 0.689,
      "impact_type": "positive"
    }
  ]
}
```

### Production FPY Analysis

```json
{
  "item": "PART_A",
  "tool": "MOLD_AN_02", 
  "fpy_percentage": 99.3,
  "trend_data": [99.1, 99.5, 99.2, 99.8, 99.0, 99.4, 99.3],
  "spc_upper_limit": 100.0,
  "spc_lower_limit": 95.7,
  "defect_breakdown": {
    "structural_issue": 54,
    "dimensional_variance": 57,
    "surface_defect": 49,
    "color_mismatch": 61,
    "contamination": 44
  }
}
```

### Quality Defects by Tool

```json
{
  "by_tool": {
    "MOLD_AN_01": {
      "defect_count": 25,
      "defect_rate": 2.1,
      "units_inspected": 1200,
      "defect_types": {
        "structural_issue": 8,
        "surface_defect": 12,
        "dimensional_variance": 5
      }
    }
  },
  "total_defects": 25,
  "total_inspected": 1200,
  "overall_rate": 2.08
}
```

### Pareto Loss Analysis

```json
{
  "pareto_analysis": [
    {
      "reason": "Changeover",
      "duration_minutes": 293,
      "frequency": 12,
      "cost_impact": 47302,
      "impact_percentage": 18.4,
      "cumulative_percentage": 18.4
    },
    {
      "reason": "Power failure", 
      "duration_minutes": 119,
      "frequency": 8,
      "cost_impact": 44052,
      "impact_percentage": 17.2,
      "cumulative_percentage": 35.6
    }
  ],
  "total_impact": 256522
}
```

### MTTR/MTBF Analysis

```json
{
  "Machine_1": {
    "mttr_minutes": 139.0,
    "mtbf_hours": 78.9,
    "health_score": 26.2
  },
  "Machine_2": {
    "mttr_minutes": 112.4,
    "mtbf_hours": 96.0, 
    "health_score": 30.8
  }
}
```

### Assembly Reconciliation

```json
{
  "total_mismatches": 25,
  "total_variance": 23884,
  "reconciliation_rate": 68.0,
  "mismatches": [
    {
      "product": "PART_C",
      "batch": "BATCH_PART_C_001",
      "produced": 1200,
      "received": 1149,
      "variance": -51,
      "variance_percentage": -4.25,
      "risk_score": 0.8,
      "tolerance_breach": false,
      "status": "reconciled"
    }
  ]
}
```

### Inventory Alerts

```json
[
  {
    "item_id": "RM_001",
    "item_name": "Raw Material A",
    "current_stock": 145.2,
    "min_threshold": 200.0,
    "max_threshold": 1000.0,
    "coverage_days": 2.1,
    "alert_type": "below_minimum",
    "reorder_proposal": {
      "quantity": 855,
      "supplier": "Supplier_A",
      "lead_time": 7
    }
  }
]
```

### Logistics Performance

```json
{
  "total_shipments": 20,
  "avg_dwell_time": 86.3,
  "sla_breach_rate": 45.0,
  "on_time_delivery": 55.0,
  "lane_analysis": {
    "Lane_1": {
      "shipments": 11,
      "avg_dwell": 72.3,
      "sla_breaches": 3
    }
  },
  "alerts": []
}
```

### CEO Brief

```json
{
  "executive_summary": "Production fell short of plan by 1,382 units due to lower OEE of 75.9%. Quality rate at 95.0% with 45% logistics SLA breaches requiring immediate attention.",
  "key_metrics": {
    "oee": 75.9,
    "quality": 95.0,
    "delivery": 55.0
  },
  "critical_issues": [
    "OEE 9.1% below target impacting production volume",
    "Logistics SLA breaches affecting customer satisfaction"
  ],
  "recommended_actions": [
    {
      "action": "Launch OEE improvement initiative focusing on availability",
      "owner": "Production Manager",
      "timeline": "This week",
      "expected_impact": "5% OEE improvement"
    }
  ],
  "financial_impact": {
    "cost_savings_potential": 100000,
    "risk_exposure": 150000
  },
  "outlook": "concerning",
  "ai_generated": true
}
```

## 🤖 AI Integration

### Gemini-First Approach
The system prioritizes Google Gemini AI for insights and predictions:

1. **Primary**: Gemini AI analysis with manufacturing domain expertise
2. **Fallback**: Custom ML models (RandomForest, Statistical Process Control)  
3. **Emergency**: Rule-based analysis for guaranteed responses

### Prediction Targets
- `oee` - Overall Equipment Effectiveness
- `quality` - First Pass Yield predictions  
- `availability` - Machine availability forecasting
- `performance` - Production rate predictions
- `downtime` - Maintenance requirement predictions

## 📈 Data Generation

### Realistic Manufacturing Scenarios
- **Tool Wear Patterns**: Progressive degradation over time
- **Seasonal Effects**: Monsoon impact, temperature variations
- **Operational Issues**: Power quality, maintenance schedules
- **Shift Variations**: Morning/afternoon/night performance differences
- **Machine Profiles**: Individual equipment characteristics

### Sample Manufacturing Data
Based on POC_Production.txt patterns with:
- 720+ historical data points for ML training
- Multi-machine production lines (10 machines)
- Quality inspection data with defect categorization
- Maintenance records with MTTR/MTBF calculations
- Logistics shipment tracking with lane analysis

## 🏗️ Architecture

### Core Components
- **FastAPI**: Modern Python web framework
- **Pydantic**: Data validation and serialization
- **Google Generative AI**: Gemini 1.5 Flash integration
- **Scikit-learn**: Machine learning models
- **NumPy/Pandas**: Statistical calculations

### Data Flow
```
Real Manufacturing Data → Enhanced Data Generator → Analytics Engine → AI Processing (Gemini/ML) → API Response
```

### Error Handling
- Graceful AI service fallbacks
- Comprehensive exception handling
- Structured error responses with confidence indicators

## 🔧 Configuration

### Environment Variables
```env
# AI Configuration  
GEMINI_API_KEY=your_gemini_api_key

# Server Configuration
HOST=0.0.0.0
PORT=8000

# Optional: Database (future use)
# DATABASE_URL=postgresql://user:pass@localhost/db

# Optional: Logging
LOG_LEVEL=INFO
LOG_FILE=logs/api.log
```

### CORS Settings
Configured for frontend integration:
- Origins: `["http://localhost:3000", "http://localhost:8080", "*"]`
- Methods: All HTTP methods allowed
- Headers: All headers allowed

## 📝 Usage Examples

### Basic OEE Analysis
```python
import requests

response = requests.get("http://localhost:8000/api/overview/executive")
data = response.json()

oee = data["oee_snapshot"]["oee"]
availability = data["oee_snapshot"]["availability"] 
performance = data["oee_snapshot"]["performance"]
quality = data["oee_snapshot"]["quality"]

print(f"OEE: {oee}% = {availability}% × {performance}% × {quality}%")
```

### AI Predictions with Fallback
```python
# Get OEE predictions for next 8 hours
response = requests.get("http://localhost:8000/api/ai/predictions?target=oee&horizon=8")
data = response.json()

print(f"Model Used: {data['model_info']['type']}")
print(f"Predictions: {data['predicted_values']}")
print(f"Confidence: {data['confidence_interval']['confidence']}")
```

### Quality Analysis
```python
# Get defect analysis by tool
response = requests.get("http://localhost:8000/api/quality/defects-by-tool?date_range=30")
data = response.json()

for tool, stats in data["by_tool"].items():
    print(f"{tool}: {stats['defect_rate']}% defect rate")
    print(f"  Top defects: {list(stats['defect_types'].keys())}")
```

## 🚨 Health Monitoring

### Health Check Endpoint
```bash
curl http://localhost:8000/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2025-08-30T13:31:08.112662",
  "version": "1.0.0"
}
```

### API Documentation
- Interactive Swagger UI: `http://localhost:8000/docs`
- ReDoc documentation: `http://localhost:8000/redoc`
- OpenAPI spec: `http://localhost:8000/openapi.json`

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📜 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Check the `/docs` endpoint for API documentation
- Review the health check endpoint for system status

---

**🏭 Built for Modern Manufacturing** - Real-time analytics, AI-powered insights, production-ready performance.