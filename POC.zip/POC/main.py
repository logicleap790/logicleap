"""
FastAPI Backend for Logic Leap Manufacturing Analytics
Main application file with core API endpoints
"""

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import json
import os
from pathlib import Path

# Import our modules
from models import *
from data_generator import DataGenerator
from enhanced_data_generator import EnhancedDataGenerator  
from analytics_engine import AnalyticsEngine
from ai_insights import AIInsightsEngine
from real_ai_insights import RealAIInsightsEngine

# Initialize FastAPI app
app = FastAPI(
    title="Logic Leap API",
    description="Manufacturing Analytics Platform Backend",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize storage
STORAGE_PATH = Path("storage")
STORAGE_PATH.mkdir(exist_ok=True)

# Initialize engines
data_gen = DataGenerator()
enhanced_data_gen = EnhancedDataGenerator()
analytics = AnalyticsEngine()
ai_engine = AIInsightsEngine()
real_ai_engine = RealAIInsightsEngine()

# ==================== OVERVIEW ENDPOINTS ====================

@app.get("/api/overview/executive", response_model=ExecutiveOverview)
async def get_executive_overview(
    plant: Optional[str] = Query(None),
    line: Optional[str] = Query(None),
    machine: Optional[str] = Query(None),
    shift: Optional[str] = Query(None),
    date: Optional[str] = Query(datetime.now().strftime("%Y-%m-%d"))
):
    """Get executive overview with OEE snapshot and key metrics"""
    try:
        # Generate or load production data
        production_data = data_gen.get_production_data(date, plant, line, machine, shift)
        
        # Calculate KPIs
        oee_metrics = analytics.calculate_oee(production_data)
        plan_vs_actual = analytics.calculate_plan_vs_actual(production_data)
        top_losses = analytics.calculate_top_losses(production_data)
        scrap_analysis = analytics.calculate_scrap_by_machine(production_data)
        
        # Get AI insights
        ai_insights = ai_engine.generate_executive_insights(
            oee_metrics, plan_vs_actual, top_losses
        )
        
        return ExecutiveOverview(
            oee_snapshot=oee_metrics,
            plan_vs_actual=plan_vs_actual,
            top_losses=top_losses,
            scrap_by_machine=scrap_analysis,
            ai_insights=ai_insights,
            timestamp=datetime.now()
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/overview/kpi-tiles")
async def get_kpi_tiles(
    date: Optional[str] = Query(datetime.now().strftime("%Y-%m-%d"))
):
    """Get KPI tiles for executive dashboard"""
    production_data = data_gen.get_production_data(date)
    return analytics.calculate_kpi_tiles(production_data)

# ==================== PRODUCTION ENDPOINTS ====================

@app.get("/api/production/shift-output", response_model=ShiftOutput)
async def get_shift_output(
    shift: str = Query(...),
    machine: Optional[str] = Query(None),
    date: Optional[str] = Query(datetime.now().strftime("%Y-%m-%d"))
):
    """Get shift output metrics"""
    production_data = data_gen.get_production_data(date, machine=machine, shift=shift)
    return analytics.calculate_shift_output(production_data)

@app.get("/api/production/downtime")
async def get_downtime_analysis(
    machine: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None)
):
    """Get downtime analysis by reason"""
    downtime_data = data_gen.get_downtime_data(machine, start_date, end_date)
    return analytics.analyze_downtime(downtime_data)

@app.get("/api/production/changeovers")
async def get_changeover_analysis(
    machine: Optional[str] = Query(None),
    date: Optional[str] = Query(datetime.now().strftime("%Y-%m-%d"))
):
    """Get changeover performance metrics"""
    changeover_data = data_gen.get_changeover_data(machine, date)
    return analytics.analyze_changeovers(changeover_data)

@app.get("/api/production/fpy", response_model=FirstPassYield)
async def get_first_pass_yield(
    item: Optional[str] = Query(None),
    tool: Optional[str] = Query(None),
    date_range: int = Query(7, description="Days to analyze")
):
    """Get First Pass Yield metrics"""
    quality_data = data_gen.get_quality_data(item, tool, date_range)
    return analytics.calculate_fpy(quality_data, item, tool)

# ==================== QUALITY ENDPOINTS ====================

@app.get("/api/quality/defects-by-tool")
async def get_defects_by_tool(
    tool_id: Optional[str] = Query(None),
    date_range: int = Query(7)
):
    """Get defect analysis by tool/mold"""
    quality_data = data_gen.get_quality_data(tool=tool_id, date_range=date_range)
    return analytics.analyze_defects_by_tool(quality_data)

@app.get("/api/quality/scrap-cost")
async def get_scrap_cost_analysis(
    machine: Optional[str] = Query(None),
    item: Optional[str] = Query(None),
    date_range: int = Query(30)
):
    """Get scrap cost analysis in INR"""
    scrap_data = data_gen.get_scrap_data(machine, item, date_range)
    return analytics.calculate_scrap_cost(scrap_data)

@app.get("/api/quality/capa")
async def get_capa_status():
    """Get CAPA (Corrective and Preventive Action) status"""
    capa_data = data_gen.get_capa_data()
    return analytics.analyze_capa(capa_data)

# ==================== DOWNTIME & LOSSES ENDPOINTS ====================

@app.get("/api/losses/pareto")
async def get_pareto_analysis(
    top_n: int = Query(10, description="Number of top reasons"),
    date_range: int = Query(7)
):
    """Get Pareto analysis of losses by reason"""
    loss_data = data_gen.get_loss_data(date_range)
    return analytics.create_pareto_analysis(loss_data, top_n)

@app.get("/api/losses/mttr-mtbf")
async def get_mttr_mtbf(
    machine: Optional[str] = Query(None),
    window: int = Query(30, description="Analysis window in days")
):
    """Get MTTR and MTBF metrics"""
    maintenance_data = data_gen.get_maintenance_data(machine, window)
    return analytics.calculate_mttr_mtbf(maintenance_data)

@app.get("/api/losses/tree")
async def get_loss_tree():
    """Get availability, performance, quality loss decomposition"""
    production_data = data_gen.get_production_data()
    return analytics.create_loss_tree(production_data)

# ==================== AI INSIGHTS ENDPOINTS ====================

@app.get("/api/ai/insights")
async def get_ai_insights(
    module: str = Query(..., description="Module name"),
    context: Optional[str] = Query(None)
):
    """Get AI-generated insights for specific module using real Gemini AI"""
    
    # Get relevant data based on module
    if module == "production":
        production_data = enhanced_data_gen.generate_comprehensive_production_data(7)
        data_context = {
            "module": module,
            "production_data": production_data[:5],  # Sample for analysis
            "data_points": len(production_data),
            "time_period": "Last 7 days",
            "context": context
        }
    elif module == "quality":
        quality_data = enhanced_data_gen.generate_quality_inspection_data(7) 
        data_context = {
            "module": module,
            "quality_data": quality_data[:5],  # Sample for analysis
            "data_points": len(quality_data),
            "time_period": "Last 7 days", 
            "context": context
        }
    else:
        # General module
        data_context = {
            "module": module,
            "timestamp": datetime.now(),
            "context": context,
            "data_points": 0
        }
    
    return await real_ai_engine.generate_ai_insights_with_gemini(data_context)

@app.get("/api/ai/predictions")
async def get_predictions(
    target: str = Query(..., description="Prediction target (oee, downtime, quality)"),
    horizon: int = Query(4, description="Prediction horizon in hours")
):
    """Get AI predictions using real ML models"""
    # Generate comprehensive historical data for ML training
    historical_production = enhanced_data_gen.generate_comprehensive_production_data(30)  # 30 days
    historical_quality = enhanced_data_gen.generate_quality_inspection_data(30)
    
    # Combine relevant data based on target
    if target in ["oee", "downtime", "performance", "availability"]:
        historical_data = historical_production
    elif target == "quality":
        historical_data = historical_quality
    else:
        historical_data = historical_production  # Default
    
    return await real_ai_engine.generate_predictions_with_gemini_first(historical_data, target, horizon)

@app.get("/api/ai/ceo-brief")
async def get_ceo_brief():
    """Generate 60-second CEO brief using real Gemini AI"""
    # Generate comprehensive real data
    production_data = enhanced_data_gen.generate_comprehensive_production_data(7)
    quality_data = enhanced_data_gen.generate_quality_inspection_data(7)
    
    all_data = {
        "production": production_data,
        "quality": quality_data,
        "production_summary": {
            "avg_oee": sum(d.get("oee_percentage", 0) for d in production_data) / len(production_data) if production_data else 0,
            "total_output": sum(d.get("actual_output", 0) for d in production_data),
            "total_planned": sum(d.get("planned_output", 0) for d in production_data),
            "data_points": len(production_data),
            "time_period": "Last 7 days"
        },
        "quality_summary": {
            "avg_fpy": sum(d.get("first_pass_yield", 0) for d in quality_data) / len(quality_data) if quality_data else 0,
            "total_inspected": sum(d.get("units_inspected", 0) for d in quality_data),
            "total_defects": sum(d.get("defects_found", 0) for d in quality_data),
            "data_points": len(quality_data)
        }
    }
    return await real_ai_engine.generate_ceo_brief_with_ai(all_data)

@app.post("/api/ai/what-if")
async def run_what_if_simulation(scenario: WhatIfScenario):
    """Run what-if simulation"""
    current_state = data_gen.get_current_state()
    return ai_engine.run_what_if_simulation(current_state, scenario)

# ==================== INVENTORY ENDPOINTS ====================

@app.get("/api/inventory/alerts")
async def get_inventory_alerts():
    """Get min/max inventory alerts"""
    inventory_data = data_gen.get_inventory_data()
    return analytics.check_inventory_alerts(inventory_data)

@app.get("/api/inventory/material-availability")
async def get_material_availability(
    date: Optional[str] = Query(datetime.now().strftime("%Y-%m-%d"))
):
    """Check material availability against production plan"""
    inventory_data = data_gen.get_inventory_data()
    production_plan = data_gen.get_production_plan(date)
    return analytics.check_material_availability(inventory_data, production_plan)

@app.get("/api/inventory/wip-aging")
async def get_wip_aging():
    """Get WIP aging analysis"""
    wip_data = data_gen.get_wip_data()
    return analytics.analyze_wip_aging(wip_data)

@app.get("/api/inventory/cycle-count")
async def get_cycle_count_status():
    """Get cycle count variance and adjustment status"""
    cycle_count_data = data_gen.get_cycle_count_data()
    return analytics.analyze_cycle_count(cycle_count_data)

@app.post("/api/inventory/cycle-count/adjustment")
async def submit_cycle_count_adjustment(adjustment_data: dict):
    """Submit cycle count adjustment"""
    return analytics.process_cycle_count_adjustment(adjustment_data)

# ==================== ASSEMBLY RECONCILIATION ENDPOINTS ====================

@app.get("/api/assembly/fg-mismatch")
async def get_fg_assembly_mismatch():
    """Get FG to Assembly mismatch analysis"""
    production_data = data_gen.get_production_data()
    assembly_data = data_gen.get_assembly_data()
    return analytics.analyze_fg_assembly_mismatch(production_data, assembly_data)

@app.get("/api/assembly/issue-drilldown")
async def get_assembly_issue_drilldown(
    item: Optional[str] = Query(None),
    batch: Optional[str] = Query(None),
    machine: Optional[str] = Query(None)
):
    """Get detailed drilldown of assembly issues"""
    return analytics.get_assembly_issue_details(item, batch, machine)

@app.post("/api/assembly/reconcile")
async def reconcile_assembly_mismatch(reconcile_data: dict):
    """Reconcile assembly mismatch"""
    return analytics.reconcile_assembly_data(reconcile_data)

@app.get("/api/assembly/release-recommendation")
async def get_release_recommendation():
    """Get recommended release quantities"""
    wip_data = data_gen.get_wip_data()
    production_plan = data_gen.get_production_plan()
    return analytics.calculate_release_recommendation(wip_data, production_plan)

@app.get("/api/assembly/traceability/{lot_number}")
async def get_lot_traceability(lot_number: str):
    """Get complete traceability for a lot"""
    return analytics.get_lot_traceability(lot_number)

# ==================== SCHEDULER ENDPOINTS ====================

@app.get("/api/scheduler/constraint-plan")
async def get_constraint_aware_plan(
    start_date: str = Query(...),
    end_date: str = Query(...)
):
    """Get constraint-aware production plan"""
    constraints = data_gen.get_constraints()
    demand = data_gen.get_demand_forecast(start_date, end_date)
    return analytics.create_constraint_plan(constraints, demand)

@app.post("/api/scheduler/scenario")
async def create_scenario_plan(scenario: SchedulerScenario):
    """Create and evaluate scenario plan"""
    base_plan = data_gen.get_production_plan()
    return analytics.evaluate_scenario(base_plan, scenario)

# ==================== LOGISTICS ENDPOINTS ====================

@app.get("/api/logistics/dispatch-receipt")
async def get_dispatch_receipt_status():
    """Get dispatch and receipt status with gate in/out times"""
    logistics_data = data_gen.get_logistics_data()
    return analytics.analyze_dispatch_receipt(logistics_data)

@app.get("/api/logistics/late-idle-loss")
async def get_late_idle_loss():
    """Get late and idle time loss analysis by lane"""
    logistics_data = data_gen.get_logistics_data()
    return analytics.analyze_late_idle_loss(logistics_data)

@app.get("/api/logistics/transport-utilization")
async def get_transport_utilization():
    """Get transport utilization analysis - FTL/LTL mix and costs"""
    transport_data = data_gen.get_transport_data()
    return analytics.analyze_transport_utilization(transport_data)

@app.get("/api/logistics/warehouse")
async def get_warehouse_metrics():
    """Get warehouse metrics including bin occupancy and pick path optimization"""
    warehouse_data = data_gen.get_warehouse_data()
    return analytics.analyze_warehouse_performance(warehouse_data)

@app.post("/api/logistics/optimize-route")
async def optimize_delivery_route(route_data: dict):
    """Optimize delivery route and load planning"""
    return analytics.optimize_logistics_route(route_data)

# ==================== ALERTS & NOTIFICATIONS ====================

@app.get("/api/alerts/exceptions")
async def get_exceptions(
    severity: Optional[str] = Query(None),
    acknowledged: bool = Query(False)
):
    """Get system exceptions and alerts"""
    return analytics.get_exceptions(severity, acknowledged)

@app.post("/api/alerts/acknowledge/{alert_id}")
async def acknowledge_alert(alert_id: str):
    """Acknowledge an alert"""
    return analytics.acknowledge_alert(alert_id)

@app.get("/api/alerts/daily-brief")
async def get_daily_brief(
    role: str = Query(..., description="User role")
):
    """Get role-based daily brief"""
    all_metrics = {
        "production": data_gen.get_production_data(),
        "quality": data_gen.get_quality_data(),
        "inventory": data_gen.get_inventory_data()
    }
    return analytics.generate_daily_brief(all_metrics, role)

# ==================== REPORTS & EXPORTS ====================

@app.get("/api/reports/export")
async def export_data(
    module: str = Query(...),
    format: str = Query("csv", description="Export format: csv, xlsx, pdf"),
    date_range: int = Query(7)
):
    """Export data in specified format"""
    data = data_gen.get_module_data(module, date_range)
    return analytics.export_data(data, format)

# ==================== HEALTH CHECK ====================

@app.get("/health")
async def health_check():
    """API health check"""
    return {
        "status": "healthy",
        "timestamp": datetime.now(),
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "message": "Logic Leap Manufacturing Analytics API",
        "documentation": "/docs",
        "health": "/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)